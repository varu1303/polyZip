import React from 'react'
import withRedux from 'next-redux-wrapper'

import EditOrganization from '../components/EditOrganization'
import { initStore } from '../libs/store'


class EditOrganizationAuth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  static async getInitialProps ({ req, query }) {
    return req
      ? { orgID: req.params.orgID }
      : { orgID: null }
    }

  render() {
    return (
        <EditOrganization orgID={this.props.orgID}/>
    )
  }
}

export default withRedux(initStore, null)(EditOrganizationAuth)
