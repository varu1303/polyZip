import React, { Component } from 'react'
import axios from 'axios'
import {Link} from '../../routes'
import Auxiliary from '../../components/HOC/Auxiliary'

class Users extends Component {
    constructor(props, context) {
        super(props, context)
        this.state = {
          gender: this.props.gender
        }
    }

    render () {
        const genderImg = (this.state.gender == "Female") ? "../../static/img/f-icon-big.png" : "../../static/img/m-icon-big.png";
        return (
            <Auxiliary>
                <div className="profile">
                    <div className="profileicon text-center">
                        <p className="normal">
                            <img src={genderImg} />
                        </p>
                        <p className="hoverable">
                            <Link route= {'/editUser/' + this.props.userId }><button className="edit"></button></Link>
                            <button className="delete" ></button>
                        </p>
                    </div>
                    <div className="user">
                        <h4>{this.props.name}</h4>
                        <p className="usertype">{this.props.role}</p>
                        <p className="email">{this.props.email}</p>
                    </div>
                </div>
                <style jsx>{`
                    .profile {
                        border-radius: 5px;
                        width: 202px;
                        background-color: white;
                        margin: 23px 0px 0px 23px;
                        display: inline-block;
                        height: 190px;
                        //
                        //border: solid 2px #d0dbe5;
                    }
                    
                    .profile .profileicon {
                        border-radius: 5px;
                        height: 86px;
                        background: #f8f8f8;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .normal {
                        margin: 0;
                    }
                    .hoverable {
                        margin: 0;
                    }

                    .profile .profileicon img {
                        height: 45px;
                        margin: auto;
                    }
                    
                    .profile .profileicon .hoverable {
                        display: none;
                    }
                    
                    .profile .profileicon:hover {
                        background: #326599;
                        box-shadow: 0px 4px 20px 1.1px rgba(50, 101, 153, 0.31);
                    }
                    
                    .profile .profileicon:hover button {
                        background-color: #5b84ad;
                        border: none;
                        margin: 0 5px;
                        border-radius: 5px;
                        cursor: pointer;
                    }
                
                    .profile .profileicon:hover .normal {
                        display: none;
                    }
                    
                    .profile .profileicon:hover .hoverable {
                        display: inline;
                    }
                    
                    .profile .user {
                        height: 94px;
                        padding: 5px;
                    }

                    .profile .user hr {
                        margin: 10px 0;
                    }

                    .profile .user h4 {
                        font-size: 12px;
                        display: inline-block;
                        width: 100%;
                        height: 19px;
                        margin: 16px 0 10px 0;
                        color: #003366;
                        //font-weight: bold;
                    }
                    .profile .user h4: hover {
                        overflow: visible;
                    }
                    
                    .profile .user p {
                        font-size: 11px;
                        color: #666666;
                        font-family: 'Tahoma';
                    }
                    .usertype {
                        margin: 0 0 12px 0;
                        display: inline-block;
                        width: 100%;
                        height: 13px;
                    }
                    .email {
                        display: inline-block;
                        width: 100%;
                        height: 13px;
                        margin: 0;
                        overflow: hidden;
                    }
                    .email:hover {
                        overflow: visible;
                    }

                    .edit {
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }

                    .delete {
                        background-image: url('../../static/img/delet.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }
                `}</style>
            </Auxiliary>
        )
    }
}
export default Users;