import React, { Component } from 'react'
import axios from 'axios'
import Auxiliary from '../../components/HOC/Auxiliary'

const Customers = (props) => (
            <Auxiliary>
                <div className="subscribers">
                    <div className="buildingicon text-center">
                        <p className="normal">
                            <img src="../../static/img/default.png" />
                        </p>
                        <p className="hoverable">
                            <button className="edit"></button>
                            <button className="delete"></button>
                        </p>
                    </div>
                    <div className="address">
                        <h4>{props.name}</h4>
                        <p>{props.address}</p>
                        <p>{props.users}</p>
                        <hr />
                    </div>
                    <div className="subscriptiontype">
                        <p className="gold"><span>Gold</span></p>
                        <p>Subscription Valid from <br />{props.date}</p>
                    </div>
                </div>
                <style jsx>{`
                    .subscribers {
                        padding: 5px;
                        border-radius: 5px;
                        width: 195px;
                        background-color: white;
                        margin: 20px 0px 0px 20px;
                        display: inline-block;
                    }
                    
                    .subscribers .buildingicon {
                        height: 60px;
                        background: #f8f8f8;
                        text-align: center;
                    }

                    .subscribers .buildingicon img {
                        height: 45px;
                        margin: auto;
                    }
                    
                    .subscribers .buildingicon .hoverable {
                        display: none;
                    }
                    
                    .subscribers .buildingicon:hover {
                        background: #326599;
                    }
                    .normal {
                        margin: 0;
                    }
                    .hoverable {
                        margin: 0;
                    }
                    .subscribers .buildingicon:hover button {
                        background-color: #5b84ad;
                        border: none;
                        margin: 0 5px;
                        border-radius: 5px;
                    }
                    
                    .subscribers .buildingicon:hover .normal {
                        display: none;
                    }
                    
                    .subscribers .buildingicon:hover .hoverable {
                        display: inline;
                    }
                    
                    .subscribers .address h4 {
                        font-size: 14px;
                        color: #326599;
                    }
                    
                    .subscribers .address hr {
                        margin: 10px 0;
                    }
                    
                    .subscribers .address p {
                        margin-bottom: 10px;
                        font-size: 11px;
                    }
                    
                    .subscribers .subscriptiontype p{
                        font-size: 12px;
                    }
                    
                    .gold {
                        background-color: #d7a407;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }
                    
                    .premiun {
                        background-color: #dd4852;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }
                    
                    .basic {
                        background-color: #2a2a2a;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }

                    .edit {
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }

                    .delete {
                        background-image: url('../../static/img/delet.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }
                `}</style>
        </Auxiliary>
);

export default Customers;