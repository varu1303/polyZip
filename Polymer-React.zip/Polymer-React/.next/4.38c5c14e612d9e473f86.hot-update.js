webpackHotUpdate(4,{

/***/ "./UI-kit/Buttons/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__primary_button__ = __webpack_require__("./UI-kit/Buttons/primary-button.js");
/* unused harmony reexport PrimaryButton */




/***/ }),

/***/ "./UI-kit/Buttons/primary-button.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/cjs/react.development.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
var _jsxFileName = 'C:\\Users\\VArun\\Desktop\\latest\\polymer-webapp\\polymer-v2\\Polymer-React\\UI-kit\\Buttons\\primary-button.js';

var _templateObject = _taggedTemplateLiteral(['\n  color: #fff;\n  font-size: 16px;\n  border: 1px solid #fff;\n  background: #32659a;\n  border-radius: 5px;\n  padding: 10px;\n  width: 100%;\n  height: 50px;\n  cursor: pointer;\n'], ['\n  color: #fff;\n  font-size: 16px;\n  border: 1px solid #fff;\n  background: #32659a;\n  border-radius: 5px;\n  padding: 10px;\n  width: 100%;\n  height: 50px;\n  cursor: pointer;\n']);

(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();

function _taggedTemplateLiteral(strings, raw) { return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var PrimaryButton = __WEBPACK_IMPORTED_MODULE_1_styled_components__["a" /* default */].button(_templateObject);

var _default = function _default(props) {
  console.log(props);
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
    PrimaryButton,
    {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 17
      }
    },
    props.title
  );
};

/* unused harmony default export */ var _unused_webpack_default_export = (_default);
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(PrimaryButton, 'PrimaryButton', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/UI-kit/Buttons/primary-button.js');
  reactHotLoader.register(_default, 'default', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/UI-kit/Buttons/primary-button.js');
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./UI-kit/MainLayout/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/cjs/react.development.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.es.js");
var _jsxFileName = 'C:\\Users\\VArun\\Desktop\\latest\\polymer-webapp\\polymer-v2\\Polymer-React\\UI-kit\\MainLayout\\index.js';

var _templateObject = _taggedTemplateLiteral(['\n  width:100%;\n  display:flex;\n  background: #d7d7d7;\n  flex-direction: column;\n  height: 100%;\n'], ['\n  width:100%;\n  display:flex;\n  background: #d7d7d7;\n  flex-direction: column;\n  height: 100%;\n']);

(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();

function _taggedTemplateLiteral(strings, raw) { return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var MainLayout = __WEBPACK_IMPORTED_MODULE_1_styled_components__["a" /* default */].div(_templateObject);

var _default = function _default(props) {
  console.log(props);
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
    MainLayout,
    {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 13
      }
    },
    props.children
  );
};

/* unused harmony default export */ var _unused_webpack_default_export = (_default);
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(MainLayout, 'MainLayout', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/UI-kit/MainLayout/index.js');
  reactHotLoader.register(_default, 'default', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/UI-kit/MainLayout/index.js');
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./components/RepoList/repoListAction.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return REQUEST_REPO_LIST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FETCH_REPO_LIST; });
/* unused harmony export ERROR_REPO_LIST_FETCH */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return REQUEST_USER_INFO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return FETCH_USER_INFO; });
/* unused harmony export ERROR_USER_FETCH */
/* unused harmony export requestRepoList */
/* unused harmony export getAllRepo */
/* unused harmony export errorForGetAllRepo */
/* unused harmony export requestUserInfo */
/* unused harmony export getUserInfo */
/* unused harmony export errorForUserInfo */
(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();

var REQUEST_REPO_LIST = 'REQUEST_EMPLOYEE_LIST';
var FETCH_REPO_LIST = 'fetch Repo list';
var ERROR_REPO_LIST_FETCH = 'error while trying to fetch Repo list';

var REQUEST_USER_INFO = 'REQUEST_USER_INFO';
var FETCH_USER_INFO = 'FETCH_USER_INFO';
var ERROR_USER_FETCH = 'error while trying to fetch User Info';

// For Repo's List
var requestRepoList = function requestRepoList(status) {
  console.log('request intiated');
  return {
    type: REQUEST_REPO_LIST,
    isFetching: status
  };
};
var getAllRepo = function getAllRepo(status, repoData) {
  console.log('fetching employee', status);
  return {
    type: FETCH_REPO_LIST,
    status: status,
    repoData: repoData
  };
};
var errorForGetAllRepo = function errorForGetAllRepo(error) {
  return {
    type: ERROR_REPO_LIST_FETCH,
    error: error
  };
};

// For User Info
var requestUserInfo = function requestUserInfo(status) {
  console.log('request intiated');
  return {
    type: REQUEST_USER_INFO,
    isFetching: status
  };
};
var getUserInfo = function getUserInfo(status, userData) {
  console.log('fetching employee', userData);
  return {
    type: FETCH_USER_INFO,
    status: status,
    userData: userData
  };
};
var errorForUserInfo = function errorForUserInfo(error) {
  return {
    type: ERROR_USER_FETCH,
    error: error
  };
};
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(REQUEST_REPO_LIST, 'REQUEST_REPO_LIST', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(FETCH_REPO_LIST, 'FETCH_REPO_LIST', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(ERROR_REPO_LIST_FETCH, 'ERROR_REPO_LIST_FETCH', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(REQUEST_USER_INFO, 'REQUEST_USER_INFO', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(FETCH_USER_INFO, 'FETCH_USER_INFO', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(ERROR_USER_FETCH, 'ERROR_USER_FETCH', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(requestRepoList, 'requestRepoList', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(getAllRepo, 'getAllRepo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(errorForGetAllRepo, 'errorForGetAllRepo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(requestUserInfo, 'requestUserInfo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(getUserInfo, 'getUserInfo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  reactHotLoader.register(errorForUserInfo, 'errorForUserInfo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListAction.js');
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./components/RepoList/repoListReducer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return fetchRepo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserInfo; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__repoListAction__ = __webpack_require__("./components/RepoList/repoListAction.js");
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();


// For Repo List
var fetchRepo = function fetchRepo() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : { isFetching: false, status: false, repoData: [] };
  var action = arguments[1];

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__repoListAction__["c" /* REQUEST_REPO_LIST */]:
      return _extends({}, state, {
        isFetching: action.isFetching
      });
    case __WEBPACK_IMPORTED_MODULE_0__repoListAction__["a" /* FETCH_REPO_LIST */]:
      return _extends({}, state, {
        isFetching: action.isFetching,
        repoData: action.repoData,
        status: action.status
      });
    default:
      return state;
  }
};
// For User Info
var UserInfo = function UserInfo() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : { isFetching: false, status: false, userInfo: {} };
  var action = arguments[1];

  switch (action.type) {
    case __WEBPACK_IMPORTED_MODULE_0__repoListAction__["d" /* REQUEST_USER_INFO */]:
      return _extends({}, state, {
        isFetching: action.isFetching
      });
    case __WEBPACK_IMPORTED_MODULE_0__repoListAction__["b" /* FETCH_USER_INFO */]:
      return _extends({}, state, {
        isFetching: action.isFetching,
        userInfo: action.userData,
        status: action.status
      });
    default:
      return state;
  }
};
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(fetchRepo, 'fetchRepo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListReducer.js');
  reactHotLoader.register(UserInfo, 'UserInfo', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/RepoList/repoListReducer.js');
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.38c5c14e612d9e473f86.hot-update.js.map