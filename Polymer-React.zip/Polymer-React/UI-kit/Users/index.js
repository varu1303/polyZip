import React, { Component } from 'react'
import axios from 'axios'
import Auxiliary from '../../components/HOC/Auxiliary'

const Users = (props) => (
            <Auxiliary>
                <div className="profile">
                    <div className="profileicon text-center">
                        <p className="normal">
                            <img src="../../static/img/m-icon-big.png" />
                        </p>
                        <p className="hoverable">
                            <button className="edit"></button>
                            <button className="delete"></button>
                        </p>
                    </div>
                    <div className="user">
                        <h4>{props.name}</h4>
                        <p className="usertype">{props.role}</p>
                        <p className="email">{props.email}</p>
                    </div>
                </div>
                <style jsx>{`
                    .profile {
                        padding: 5px;
                        border-radius: 5px;
                        width: 195px;
                        background-color: white;
                        margin: 20px 0px 0px 20px;
                        display: inline-block;
                    }
                    
                    .profile .profileicon {
                        height: 60px;
                        background: rgb(248, 248, 248);
                        text-align: center;
                    }
                    .normal {
                        margin: 0;
                    }
                    .hoverable {
                        margin: 0;
                    }

                    .profile .profileicon img {
                        height: 45px;
                        margin: auto;
                    }
                    
                    .profile .profileicon .hoverable {
                        display: none;
                    }
                    
                    .profile .profileicon:hover {
                        background: #326599;
                    }
                    
                    .profile .profileicon:hover button {
                        background-color: #5b84ad;
                        border: none;
                        margin: 0 5px;
                        border-radius: 5px;
                    }
                
                    .profile .profileicon:hover .normal {
                        display: none;
                    }
                    
                    .profile .profileicon:hover .hoverable {
                        display: inline;
                    }
                    
                    .profile .user {
                        word-wrap: break-word;
                    }

                    
                    
                    .profile .user hr {
                        margin: 10px 0;
                    }
                    
                    .profile .user p {
                        margin-bottom: 10px;
                    }
                                        
                    .email {
                        font-size: 12px;
                    }
                    .edit {
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }

                    .delete {
                        background-image: url('../../static/img/delet.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }
                `}</style>
            </Auxiliary>
        );
    
export default Users;