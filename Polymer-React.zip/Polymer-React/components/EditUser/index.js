import React, { Component } from 'react'
import axios from 'axios'
import {Router} from '../../routes'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import Title from './title'
import Sidebar from '../../UI-kit/Sidebar'
import Profile from '../../UI-kit/Profile'

class EditUser extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
        userId: 0,
        username: '',
        //password: 'user123',
        first_name: '',
        last_name: '',
        email: '',
        phonenumber: '',
        organizationID: 1,
        departmentID: 1,
        gender: '',
        roleID: 0,
        useractive: true,
        validForm: false,
        urlId: this.props.userID
    }
  }

  getInitialProps() {

  }

  componentDidMount() {
    axios.get('http://localhost:1337/user')
      .then(data => {
        //console.log(data.data);
        console.log(this.state.urlId);
        data.data.forEach(user => {
            //console.log(user)
            if( user.userID == this.state.urlId ) {
                console.log(true);
                this.setState({
                    userId: user.userID,
                    username: user.username,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                    phonenumber: user.phonenumber,
                    organizationID: user.organizationID,
                    departmentID: user.departmentID,
                    gender: user.gender,
                    roleID: user.roleID,
                    useractive: user.useractive
                })
            }
        });
      })
      .catch(error => {
        console.log(error);
      })
  }

  validateForm = () => {
    if (this.state.first_name && this.state.last_name && this.state.email && this.state.gender && this.state.roleID) {
       this.setState(() => ({
           username: this.state.first_name + " " + this.state.last_name.charAt(0)
       }));
        this.setState(() => ({
            validForm: true  
          }))
    }else {
      this.setState(() => ({
        validForm: false  
      }))     
    }
  }

  // Update state on change on value in input fields
  handlechange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    
    this.setState(() => ({
      [name]: value
    }), ()=>this.validateForm() )
  }

  editUser = (event) => {
    event.preventDefault();
    console.log(this.state);
    axios.put('http://localhost:1337/user/'+this.state.urlId, (this.state))
      .then(data => {
        console.log(data);
        // localStorage.setItem('CreatedORGID', data.data.organizationID);
        Router.pushRoute('/manageUsers/'+ this.state.organizationID);
      })
      .catch(error => {
        console.log('Error in saving organization', error);
      })
  }
  maintainState = event => {
    let key = event.target.id;
    let val = event.target.value;
    if (key === 'roleID')
      val = parseInt(val);

    this.setState(() => {
      return ({
        [key]: val
      })
    })
  }
  

  render() {

    return (
    <div>
            <Sidebar />
            <div className="mainpage">
            <div>
                <div className="headerpart">
                    <h2>ADD NEW CUSTOMERS</h2>
                    <p>Logged in as Administrator-<span className="font-weight-bold">Clinton, S </span><i className="down"></i></p>
                </div>
                <div className="wizard">
                    <a className="done" href="#"><span className="doneBadge">1</span>Customer Details</a>
                    <a className="current" href="#"><span className="badge" href="#">2</span>Add Users</a>
                    <a><span className="badge" href="#"> </span></a>
                </div>
            </div>
            <div className="bodypart">
                <form action="#" onChange={this.maintainState} onSubmit={this.editUser} >
                    <fieldset>
                            <legend>User Details</legend>
                            <p>
                                <label className="mainlabels" htmlFor="first_name">First Name</label>
                                <input className="secondaryinputs" name="first_name" type="text" id="first_name" value={this.state.first_name} onChange={this.handlechange} />
                                <label className="secondarylabels" htmlFor="last_name">Last Name</label>
                                <input className="secondaryinputs" name="last_name" type="text"  id="last_name" value={this.state.last_name} onChange={this.handlechange} />
                            </p>
                            <p>
                                <label className="mainlabels" htmlFor="gender">Gender</label>
                                <select className="gender" name="gender" id="gender" value={this.state.gender} onChange={this.handlechange} >
                                    <option value=""></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </p>
                            <hr />
                            <p>
                                <label className="mainlabels" htmlFor="email">Email ID</label>
                                <input className="maininputs" name="email" type="email"   id="email" value={this.state.email} onChange={this.handlechange}/>
                            </p>
                            <hr />
                            <p>
                                <label className="mainlabels" htmlFor="roleID">User Role</label>
                                <select className="userRoleDropdown" name="roleID" id="roleID" value={this.state.roleID} onChange={this.handlechange} >
                                    <option value=""></option>
                                    <option value="1">Administrator</option>
                                    <option value="2">User</option>
                                </select>
                            </p>
                            {/* <p>
                                <button className="addbutton" type="submit" disabled={!this.state.validForm} >Add</button>
                            </p> */}
                            <div className="buttons">
                                <p>
                                    <button className="primarybutton" type="submit" disabled={!this.state.validForm} >Save & Finish</button>
                                    <button className="secondarybutton" type="reset">Reset</button>
                                </p>
                                <p>
                                    <button className="secondarybutton" disabled={!this.state.validForm}>Cancel</button>
                                </p>
                            </div>
                        </fieldset>
                        <div className="numberOfUsers">
                            <p>01 Users Added</p>
                        </div>
                </form>
                <Profile name="David Rossman" role="Administrator" email="david.rossman@barclays.com" gender="Male" />
            </div>
        </div>
        <style jsx>{`
          .mainpage {
            height: 100%;
            margin-left: 15%;
            width: 85%;
        }

        /* Top header */
        .headerpart {
            display: flex;
            width: 98%;
            padding: 10px;
            background-color: #ffffff;
            border-bottom-style: solid;
            border-width: 1px;
            border-bottom-color: lightgrey;
            align-items: center;
            justify-content: space-between;
            height: 5.2%;
        }

        /* Heading */
        .headerpart h2 {
            font-size: 16px;
            margin: 0;
            color: #666666;
            font-weight: bold;
        }

        /* Logged in as */
        .headerpart p {
            font-size: 11px;
            margin: 0;
        }

        .headerpart p span {
            font-weight: bold;
        }
            .headerpart p i {
                border: solid black;
                border-width: 0 3px 3px 0;
                display: inline-block;
                padding: 3px;
            }
            .headerpart p .down {
                transform: rotate(45deg);
                -webkit-transform: rotate(45deg);
            }

            .wizard {
                margin: 20px;
            }

            .wizard a {
                padding: 10px 12px 10px;
                margin-right: 5px;
                background: #bbcede;
                position: relative;
                display: inline-block;
                width: 171px;
                cursor: pointer;
                font-size: 16px;
                text-decoration: none;
            }
            .wizard a:last-child {
                width: calc(100% - 366px);
                backbackground: #d0dbe5;
            }
            .wizard a:before {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid rgb(236, 236, 236);
                position: absolute;
                content: "";
                top: 0;
                left: 0;
            }
            .wizard a:after {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid #ffffff;
                position: absolute;
                content: "";
                top: 0;
                right: -20px;
                z-index: 2;
            }
            .wizard a:first-child:before,
            .wizard a:last-child:after {
                border: none;
            }

            .wizard a:first-child {
                -webkit-border-radius: 4px 0 0 4px;
                -moz-border-radius: 4px 0 0 4px;
                        border-radius: 4px 0 0 4px;
            }
            .wizard a:last-child {
                -webkit-border-radius: 0 4px 4px 0;
                -moz-border-radius: 0 4px 4px 0;
                        border-radius: 0 4px 4px 0;
            }
            .wizard .badge {
                border-radius: 4px;
                margin: 0 5px 0 18px;
                position: relative;
                top: -1px;
                color: #666666;
                background-color: #f6f6f6;
                display: inline-block;
                width: 23px;
                height: 23px;
                text-align: center;
            }
            .wizard .doneBadge {
                border-radius: 4px;
                margin: 0 5px 0 0px;
                position: relative;
                top: -1px;
                color: #ffffff;
                background-color: #326599;
                display: inline-block;
                width: 23px;
                height: 23px;
                text-align: center;
            }
            .wizard a:first-child .badge {
                margin-left: 0;
            }
            .wizard .current {
                background: #dd4852;
                color: #fff;
            }
            .wizard .current:after {
                border-left-color: #dd4852;
            }
            .wizard .done {
                background: #ffffff;
                color: #000000;
            }

            .bodypart {
                margin: 20px;
            }

            legend {
                font-size: 13px;
                line-height: 20px;
                margin-bottom: 0;
                width: auto;
                font-weight: bold;   
            }

            fieldset {
                border: 1px solid #d0dbe5;
                padding: 10px 21px;
            }

            hr {
                border-width: 1px;
                border-color: #d0dbe5
            }

            .buttons {
                display: flex;
                justify-content: space-between;
            }

            .bodypart p {
                margin: 16px 0;
            }

            .mainlabels {
                width: 62px;
                margin-right: 35px;
                font-size: 13px;
                display: inline-block;
            }

            .secondarylabels {
                width: 85px;
                margin-right: 35px;
                margin-left: 28px;
                font-size: 13px;
                display: inline-block;
            }

            select > option[value=""] {
                display: none;
            }

            .maininputs {
                width: 393px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
                margin-top: 26px;
                margin-bottom: 26px;
            }
            .secondaryinputs {
                width: 173px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .userRoleDropdown {
                width: 173px;
                height: 28px;
                font-size: 13px;
                margin-top: 26px;
                margin-bottom: 26px;
            }

            .gender {
                width: 123px;
                height: 28px;
                font-size: 13px;
                margin-bottom: 25px;
            }
            
            .numberOfUsers {
                background-color: #6d6d6d;
                color: white;
                margin: 10px 0 20px 0;
                padding: 4px;
                font-size: 14px;
            }
            
            .numberOfUsers p {
                margin: 0;
                font-size: 14px;
            }
            
            .primarybutton {
                margin: 0 10px 0 0;
                padding: 0;
                height: 40px;
                cursor: pointer;
                width: 120px;
                color: white;
                background-color: rgb(50, 101, 153);
                font-size: 14px;
            }

            .secondarybutton {
                margin: 0 10px 0 0;
                padding: 0;
                height: 40px;
                cursor: pointer;
                width: 120px;
                color: rgb(50, 101, 153);
                background-color: white;
                border: 1px solid rgb(50, 101, 153);
                font-size: 14px;
            }
            
      `}</style>
    </div>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(EditUser)
