import React from 'react'
import withRedux from 'next-redux-wrapper'

import AddNewUser2 from '../components/AddNewUser2'
import { initStore } from '../libs/store'


class AddNewUser2Auth extends React.Component{
    constructor(props, context) {
      super(props, context)
      this.state = {
        repoName :props.value
      }
    }

    static async getInitialProps ({ req, query }) {
      return req
        ? { orgId: req.params.orgId }
        : { orgId: null }
    }
  
    render() {
      return (
          <AddNewUser2 orgId={this.props.orgId} />
      )
    }
  }
  
  export default withRedux(initStore, null)(AddNewUser2Auth)
  