import React, { Component } from 'react'
import axios from 'axios'
import Auxiliary from '../../components/HOC/Auxiliary'


const Profile = (props)=>(
            <Auxiliary>
                <div className="users">
                            <div className="userprofile">
                                <div className="userinfo">
                                    <img src="../../static/img/m-icon.png" height="30px" width="30px" />
                                    <div className="name_role">
                                        <p className="username">{props.name}</p>
                                        <p className="user-role">{props.role}</p>
                                    </div>
                                </div>
                                <p className="user-email">{props.email}</p>
                            </div>
                            <div className="editicon">
                                <button className="editButton"></button>
                            </div>
                        </div>
                
                <style jsx>{`
                    .users {
                        display: inline-block;
                        width: 256px;
                        padding: 5px;
                        margin-right: 10px;
                        margin-bottom: 10px;
                        background-color: white;
                    }
                                
                    .userinfo {
                        display: flex;
                    }
                    
                    .name_role {
                        margin-left: 5px;
                    }
                    
                    .name_role  p {
                        margin: 0;
                    }
        
                    .username {
                        font-size: 13px;
                        font-weight: bold;
                        margin: 0;
                    }
                    
                    .user-role {
                        font-size: 13px;
                        margin: 0;
                    }
                    .user-email {
                        margin: 5px 0 0 0;
                        font-size: 13px;
                    }
        
                    .userprofile {
                        display: inline-block;
                        border-right-style: solid;
                        border-width: 2px;
                        border-color: rgb(246, 246, 246);
                        width:211px;
                    }
                    
                    .editicon {
                        display: inline-block;
                    }
                    .editicon .editButton {
                        height: 40px;
                        width: 40px;
                        border: none;
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        cursor: pointer;
                        color: white;
                    }
                `}</style>
            </Auxiliary>
        );

    

export default Profile;