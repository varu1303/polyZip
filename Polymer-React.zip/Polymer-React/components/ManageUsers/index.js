import React, { Component } from 'react'
import axios from 'axios'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import Sidebar from '../../UI-kit/Sidebar'
import {InputBox} from '../../UI-kit/InputTypes'
import Title from './title'
import Users from '../../UI-kit/Users'
class ManageUsers extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
      users: [],
      adminCount: 0,
      totalCount: 0,
      userCount: 0
    }
  }
  getInitialProps() {

  }

  componentWillMount() {
  }

  componentDidMount() {
    console.log('USER MOUNTED');
    axios.get('http://localhost:1337/user')
      .then(data => {
        // console.log(data.data);
        let totalCount = 0;
        let userCount = 0;
        let adminCount = 0;
        data.data.forEach(user => {
          totalCount += 1;
          if (user.roleID === 1)
            adminCount += 1;
        })
        userCount = totalCount - adminCount;
        this.setState(() => {
          return ({
            users: data.data,
            totalCount,
            userCount,
            adminCount
          })
        })
      })
      .catch(error => {
        console.log(error);
      })
  }

  render() {

    return (
        <div>
          <Sidebar />
          
          <div className="mainpage">
                    <div>
                        <div className="headerpart justify-content-between">
                            <div><h2 className="font-weight-bold">MANAGE USERS</h2><h3>/ Barclays</h3></div>
                                <p>Logged in as Administrator-<span className="font-weight-bold">Clinton, S </span><a><i className="down"></i></a></p>
                            </div>
                        <div className="headercontent justify-content-between">
                            <nav className="nav justify-content-start">
                                <a className="nav-link navwidth nav-item" href="#"><p className="text-left">Total Users</p><h1 className="text-left">{this.state.totalCount}</h1></a>
                                <a className="nav-link navwidth nav-item" href="#"><p className="text-left">Administrator</p><h1 className="text-left">{this.state.adminCount}</h1></a>
                                <a className="nav-link navwidth nav-item" href="#"><p className="text-left">Users</p><h1 className="text-left">{this.state.userCount}</h1></a>
                            </nav>
                            <div className="add_search_button_div">
                                <button className="searchbutton"></button>
                                <button className="buttonwidth">Add New</button>
                            </div>
                        </div>
                    </div>
                <div className="bodypart">
                  {
                    this.state.users.map((user, i) => {
                      return <Users key={i} name={user.username} role={user.roleId}  email={user.email}     />                
                    })
                  }
                </div>
            </div>
        <style jsx>{`
          .mainpage {
            height: 100%;
            margin-left: 15%;
            width: 85%;
        }
        
        // Top header
        .headerpart {
            display: flex;
            width: 98%;
            padding: 10px;
            background-color: #ffffff;
            border-bottom-style: solid;
            border-width: 1px;
            border-bottom-color: lightgrey;
            align-items: center;
            justify-content: space-between;
        }
        
        // Heading
        .headerpart h2 {
            font-size: 16px;
            margin: 0;
            color: #666666;
            font-weight: bold;
            display: inline;
        }
        .headerpart h3 {
            font-size: 12px;
            margin: 0;
            color: #666666;
            font-weight: bold;
            display: inline;
        }
        
        // Logged in as 
        .headerpart p {
            font-size: 11px;
            margin: 0;
        }
        .headerpart p span {
            font-weight: bold;
        }
        .headerpart p a {
            cursor: pointer;
        }
        .headerpart p a i {
            border: solid black;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 3px;
        }
        .headerpart p .down {
            transform: rotate(45deg)
        }
        
        // header tabs 
        .headercontent {
            display: flex;
            padding: 15px;
            align-items: center;
            background-color: #fafafa;
            justify-content: space-between;
        }

        .headercontent nav {
          justify-content: start;
        }
        
        @media screen and (max-width: 350px) {
            .headercontent {
                display: block;
            }
        }
        
        
        .headercontent nav a {
            border-left-style: solid;
            border-width: 1px;
            border-color: rgb(244, 246, 247);
            padding: 12px 10px;
            text-decoration: none;
            text-align: center;
            display: inline-block
        }
        
        .headercontent nav a:hover {
            border-bottom-style: solid;
            border-bottom-width: 4px;
            padding: 12px 10px 8px 10px;
            border-bottom-color: #dd4852;
        }
        
        .headercontent nav a p {
            color: #666666;
            font-size: 15px;
            margin: 0;
        }
        
        .headercontent nav a h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
            color: #003366;
        }
        
        .headercontent .navwidth {
            width: 160px;
        }
        
        .headercontent button {
            padding: 0;
            height: 40px;
            cursor: pointer;
        }
        
        .headercontent .buttonwidth {
            width: 150px;
            color: white;
            background-color: #326599;
            margin: 5px;
        }
        
        .headercontent .searchbutton {
            width: 50px;
            background-color: white;
            color: lightgray;
            font-size: 25px;
            background-image: url('../../static/img/search.png');
            background-repeat: no-repeat;
            background-position: center;
            margin: 5px;
        }
        .add_search_button_div {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .text-left {
            text-align: left;
        }
        .bodypart {
            margin: 0;
            padding: 0;
        }
      `}</style>
      </div>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ManageUsers)
