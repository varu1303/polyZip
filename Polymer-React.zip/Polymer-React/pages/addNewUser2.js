import React from 'react'
import withRedux from 'next-redux-wrapper'

import AddNewUser2 from '../components/AddNewUser2'
import { initStore } from '../libs/store'


class AddNewUser2Auth extends React.Component{
    constructor(props, context) {
      super(props, context)
      this.state = {
        repoName :props.value
      }
    }
  
    render() {
      return (
          <AddNewUser2 />
      )
    }
  }
  
  export default withRedux(initStore, null)(AddNewUser2Auth)
  