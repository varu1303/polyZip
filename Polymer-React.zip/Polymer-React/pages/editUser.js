import React from 'react'
import withRedux from 'next-redux-wrapper'

import EditUser from '../components/EditUser'
import { initStore } from '../libs/store'


class EditUserAuth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  static async getInitialProps ({ req, query }) {
    return req
      ? { userID: req.params.userID }
      : { userID: null }
    }

  render() {
    return (
        <EditUser userID={this.props.userID} />
    )
  }
}

export default withRedux(initStore, null)(EditUserAuth)
