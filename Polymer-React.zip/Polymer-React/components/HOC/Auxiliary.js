const aux = (props) => props.children;

export default aux;