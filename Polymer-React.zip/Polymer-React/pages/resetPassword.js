import React from 'react'
import withRedux from 'next-redux-wrapper'

import ResetPassword from '../components/ResetPassword'
import { initStore } from '../libs/store'


class ResetPasswordAuth extends React.Component{
    constructor(props, context) {
      super(props, context)
      this.state = {
        repoName :props.value
      }
    }
  
    render() {
      return (
          <ResetPassword />
      )
    }
  }
  
  export default withRedux(initStore, null)(ResetPasswordAuth)
  