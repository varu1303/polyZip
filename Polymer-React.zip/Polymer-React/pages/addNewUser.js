import React from 'react'
import withRedux from 'next-redux-wrapper'

import AddNewUser from '../components/AddNewUser'
import { initStore } from '../libs/store'


class AddNewUserAuth extends React.Component{
    constructor(props, context) {
      super(props, context)
      this.state = {
        repoName :props.value
      }
    }
  
    render() {
      return (
          <AddNewUser />
      )
    }
  }
  
  export default withRedux(initStore, null)(AddNewUserAuth)
  