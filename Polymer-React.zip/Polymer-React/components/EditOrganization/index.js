import React, { Component } from 'react'
import axios from 'axios'
import {Router} from '../../routes'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import { PrimaryButton } from '../../UI-kit/Buttons'
import Title from './title'
import Sidebar from '../../UI-kit/Sidebar'

class EditOrganization extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
        organizationId: 0,
        organization_Name: '',
        add1: '',
        add2: '',
        cityID: 0,
        countryID: 0,
        stateID: 0,
        zip: null,
        contactPerson: '',
        email: '',
        phone: '',
        subscriptionID: 1,
        subscription_startDate: null,
        organization_status: true,
        validForm: false,
        urlId: this.props.orgID,
        //organizations: []
    }
  }

  getInitialProps() {

  }

  componentDidMount() {
      
    axios.get('http://localhost:1337/organization')
    .then(data => {
        //console.log(data.data)
        data.data.forEach( org => {
            if(org.organizationID == this.state.urlId){
                this.setState({
                    organizationId: org.organizationID,
                    organization_Name: org.organization_Name,
                    add1: org.add1,
                    add2: org.add2,
                    cityID: org.cityID,
                    countryID: org.countryID,
                    stateID: org.stateID,
                    zip: org.zip,
                    contactPerson: org.contactPerson,
                    email: org.email,
                    phone: org.phone,
                    subscriptionID: org.subscriptionID,
                    subscription_startDate: org.subscription_startDate,
                    organization_status: org.organization_status
                })
            }
        })      
    })
    .catch(error => {
      console.log(error);
    })
  }

  validateForm = () => {
    if (this.state.organization_Name && this.state.stateID && this.state.countryID && this.state.subscription_startDate) {
       
        this.setState(() => ({
            validForm: true  
          }))
    }else {
      this.setState(() => ({
        validForm: false  
      }))     
    }
  }

  // Update state on change on value in input fields
  handlechange = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    
    this.setState(() => ({
      [name]: value
    }), ()=>this.validateForm() )
  }

  editOrganization = (event) => {
    event.preventDefault();
    console.log(this.state);
    axios.put('http://localhost:1337/organization/'+this.state.urlId, (this.state))
      .then(data => {
        console.log(data);
        // localStorage.setItem('CreatedORGID', data.data.organizationID);
        Router.pushRoute('/manageCustomers/');
      })
      .catch(error => {
        console.log('Error in saving organization', error);
      })
  }

  maintainState = event => {
    let key = event.target.id;
    let val = event.target.value;
    if (key === 'cityID' || key === 'stateID' || key === 'countryID' || key === 'phone' || key === 'subscriptionID')
      val = parseInt(val);
    // if (key === 'zip') 
    //   val = null;
    this.setState(() => {
      return ({
        [key]: val
      })
    })
  }
  

  render() {
      //console.log(this.state.organizations)
     
    return (
    <div>
            <Sidebar />
            <div className="mainpage">
            <div>
                <div className="headerpart">
                    <h2>ADD NEW CUSTOMERS</h2>
                    <p>Logged in as Administrator-<span className="font-weight-bold">Clinton, S </span><i className="down"></i></p>
                </div>
                <div className="wizard">
                    <a className="current" href="#"><span className="badge">1</span>Customer Details</a>
                    <a><span className="nextBadge" href="#">2</span>Add Users</a>
                    <a><span className="badge" href="#"> </span></a>
                </div>
            </div>
            <div className="bodypart">
                <form action="#" onSubmit={this.editOrganization} onChange={this.maintainState} >
                    <fieldset>
                        <legend>General Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="organization_Name">Customer Name</label>
                            <input 
                                className="maininputs"
                                name="organization_Name"
                                type="text"
                                id="organization_Name"
                                value={this.state.organization_Name} 
                                onChange={this.handlechange}
                            />
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Address Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="add1">Address Line 1</label>
                            <input 
                                className="maininputs"
                                name="add1"
                                type="text"
                                id="add1"
                                value={this.state.add1}
                                onChange={this.handlechange}
                            />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="add2">Address Line 2</label>
                            <input
                                className="maininputs"
                                name="add2"
                                type="text" id="add2"
                                value={this.state.add2}
                                onChange={this.handlechange}
                            />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="countryID">Country</label>
                            <select className="countrydropdown" name="countryID"  id="countryID" value={this.state.countryID} onChange={this.handlechange}>
                                <option value=""></option>
                                <option value="1">India</option>
                                <option value="2">IN</option>
                            </select>
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="stateID">State/Province</label>
                            <select className="statedropdown" name="stateID"  id="stateID" value={this.state.stateID} onChange={this.handlechange}>
                                <option value=""></option>
                                <option value="1">Maha</option> 
                                <option value="2">Maharashtra</option>
                            </select>
                            <label className="citylabel" htmlFor="cityID">City</label>
                            <select className="citydropdown" name="cityID"  id="cityID" value={this.state.cityID} onChange={this.handlechange}>
                                <option value="1">Pune</option>
                                <option value="2">Pun</option>
                            </select>
                            <label className="secondarylabels" htmlFor="zip">Postal Code</label>
                            <input
                                className="postalcodeinput"
                                name="zip"
                                type="text"
                                value={this.state.zip}
                                onChange={this.handlechange}
                            />
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Contact Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="contactPerson">Contact Person</label>
                            <input 
                                className="contactinfoinput"
                                name="contactPerson"
                                type="text" 
                                id="contactPerson"
                                value={this.state.contactPerson} 
                                onChange={this.handlechange}
                            />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="email">E-mail ID</label>
                            <input 
                                className="contactinfoinput"
                                name="email"
                                type="email"
                                id="email"
                                value={this.state.email}
                                onChange={this.handlechange}
                            />
                            <label className="secondarylabels" htmlFor="phone">Phone</label>
                            <input
                                className="contactinfophoneinput"
                                name="phone"
                                type="text"
                                id="phone"
                                value={this.state.phone}
                                onChange={this.handlechange}
                            />
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Subscription Details</legend>
                        <p>
                            <label className="mainlabels" htmlFor="subscriptionID">Select Subscription</label>
                            <select className="subscriptiondropdown" name="subscriptionID"  id="subscriptionID" value={this.state.subscriptionID} onChange={this.handlechange}>
                                <option value="1">Platinum</option>
                                <option value="2">Gold</option>
                            </select>
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="duration">Duration</label>
                            <select className="durationdropdown" name="duration">
                                <option value="1">1 Year</option>
                            </select>
                            <label className="secondarylabels" htmlFor="subscription_startDate">Starts from</label>
                            <input className="starts-from" name="subscription_startDate" type="date"  id="subscription_startDate" value={this.state.subscription_startDate} onChange={this.handlechange} />
                        </p>
                    </fieldset>
                    <div className="buttons">
                        <p>
                            <button className="primarybutton" type="submit" disabled={!this.state.validForm} >Save & Next</button>
                            <button className="secondarybutton" type="reset">Reset</button>
                        </p>
                        <p>
                            <button className="secondarybutton" disabled={!this.state.validForm}>Cancel</button>
                        </p>
                    </div>
                </form>
            </div>
        </div>
        <style jsx>{`
          .mainpage {
                height: 100%;
                margin-left: 15%;
                width: 85%;
            }

            /* Top header */
            .headerpart {
                display: flex;
                width: 98%;
                padding: 10px;
                background-color: #ffffff;
                border-bottom-style: solid;
                border-width: 1px;
                border-bottom-color: lightgrey;
                align-items: center;
                justify-content: space-between;
                height: 5.2%;
            }

            /* Heading */
            .headerpart h2 {
                font-size: 16px;
                margin: 0;
                color: #666666;
                font-weight: bold;
            }

            /* Logged in as */
            .headerpart p {
                font-size: 11px;
                margin: 0;
            }

            .headerpart p span {
                font-weight: bold;
            }
            
            .headerpart p i {
                border: solid black;
                border-width: 0 3px 3px 0;
                display: inline-block;
                padding: 3px;
            }
            .headerpart p .down {
                transform: rotate(45deg);
                -webkit-transform: rotate(45deg);
            }

            .wizard {
                margin: 20px;
            }

            .wizard a {
                padding: 10px 12px 10px;
                margin-right: 5px;
                background: #bbcede;
                position: relative;
                display: inline-block;
                width: 171px;
                cursor: pointer;
                font-size: 16px;
                text-decoration: none;
            }
            .wizard a:last-child {
                width: calc(100% - 366px);
                backbackground: #d0dbe5;
            }
            .wizard a:before {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid rgb(236, 236, 236);
                position: absolute;
                content: "";
                top: 0;
                left: 0;
            }
            .wizard a:after {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid rgb(187, 206, 221);
                position: absolute;
                content: "";
                top: 0;
                right: -20px;
                z-index: 2;
            }
            .wizard a:first-child:before,
            .wizard a:last-child:after {
                border: none;
            }

            .wizard a:first-child {
                -webkit-border-radius: 4px 0 0 4px;
                -moz-border-radius: 4px 0 0 4px;
                        border-radius: 4px 0 0 4px;
            }
            .wizard a:last-child {
                -webkit-border-radius: 0 4px 4px 0;
                -moz-border-radius: 0 4px 4px 0;
                        border-radius: 0 4px 4px 0;
            }
            .wizard .badge {
                border-radius: 4px;
                margin: 0 5px 0 18px;
                position: relative;
                top: -1px;
                color: #747474;
                background-color: #fcfcfc;
                display: inline-block;
                width: 23px;
                height: 23px;
                text-align: center;
            }
            .wizard .nextBadge {
                border-radius: 4px;
                margin: 0 5px 0 18px;
                position: relative;
                top: -1px;
                color: #666666;
                background-color: #f6f6f6;
                display: inline-block;
                width: 23px;
                height: 23px;
                text-align: center;
            }
            .wizard a:first-child .badge {
                margin-left: 0;
            }
            .wizard .current {
                background: #dd4852;
                color: #fff;
            }
            .wizard .current:after {
                border-left-color: #dd4852;
            }

            .bodypart {
                margin: 20px;
            }

            legend {
                font-size: 13px;
                line-height: 20px;
                margin-bottom: 0;
                width: auto;
                font-weight: bold;   
            }

            fieldset {
                border: 1px solid #d0dbe5;
                padding: 10px 21px;
            }
            select > option[value=""] {
                display: none;
            }

            .buttons {
                display: flex;
                margin-top: 28px;
                justify-content: space-between;
            }

            .bodypart p {
                margin-bottom: 10px;
            }

            .mainlabels {
                width: 140px;
                margin-right: 8px;
                font-size: 13px;
                display: inline-block;
            }

            .secondarylabels {
                width: 85px;
                margin-right: 8px;
                margin-left: 50px;
                font-size: 13px;
                display: inline-block;
            }

            .citylabel {
                margin-right: 10px;
                margin-left: 50px;
                width: 50px;
                font-size: 13px;
                display: inline-block;
            }

            .maininputs {
                width: 393px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .countrydropdown {
                width: 229px;
                font-size: 13px;
                height: 28px;
            }

            .statedropdown {
                width: 123px;
                font-size: 13px;
                height: 28px;
            }

            .citydropdown {
                width: 163px;
                font-size: 13px;
                height: 28px;
            }

            .contactinfoinput {
                width: 332px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .contactinfophoneinput {
                width: 163px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .postalcodeinput {
                width: 111px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .subscriptiondropdown {
                width: 163px;
                font-size: 13px;
                height: 28px;
            }

            .durationdropdown {
                width: 123px;
                font-size: 13px;
                height: 28px;
            }

            .starts-from {
                width: 130px;
                font-size: 13px;
                height: 26px;
                border-width: 1px;
                padding: 0;
            }

            .primarybutton {
                margin: 0 13px 0 0;
                padding: 0;
                height: 36px;
                cursor: pointer;
                width: 127px;
                color: white;
                background-color: rgb(50, 101, 153);
                font-size: 14px;
            }

            .secondarybutton {
                margin: 0 13px 0 0;
                padding: 0;
                height: 36px;
                cursor: pointer;
                width: 127px;
                color: rgb(50, 101, 153);
                background-color: white;
                border: 1px solid rgb(50, 101, 153);
                font-size: 14px;
            }
      `}</style>
    </div>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(EditOrganization)
