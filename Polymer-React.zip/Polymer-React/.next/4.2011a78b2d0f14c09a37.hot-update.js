webpackHotUpdate(4,{

/***/ "./components/AddNewUser/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/cjs/react.development.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_axios__ = __webpack_require__("./node_modules/axios/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__routes__ = __webpack_require__("./routes.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__routes___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__routes__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux__ = __webpack_require__("./node_modules/react-redux/es/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_redux__ = __webpack_require__("./node_modules/redux/es/redux.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__repoListActionCreator__ = __webpack_require__("./components/AddNewUser/repoListActionCreator.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__UI_kit_Buttons__ = __webpack_require__("./UI-kit/Buttons/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__UI_kit_MainLayout__ = __webpack_require__("./UI-kit/MainLayout/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__UI_kit_InputTypes__ = __webpack_require__("./UI-kit/InputTypes/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__title__ = __webpack_require__("./components/AddNewUser/title.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__UI_kit_Sidebar__ = __webpack_require__("./UI-kit/Sidebar/index.js");
var _jsxFileName = 'C:\\Users\\VArun\\Desktop\\latest\\polymer-webapp\\polymer-v2\\Polymer-React\\components\\AddNewUser\\index.js';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();



(function () {
    var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }













var AddNewUser = function (_Component) {
    _inherits(AddNewUser, _Component);

    function AddNewUser(props, context) {
        _classCallCheck(this, AddNewUser);

        var _this = _possibleConstructorReturn(this, (AddNewUser.__proto__ || Object.getPrototypeOf(AddNewUser)).call(this, props, context));

        _this.postOrganization = function (event) {
            event.preventDefault();
            console.log(_this.state);
            __WEBPACK_IMPORTED_MODULE_2_axios___default.a.post('http://localhost:1337/organization', _this.state).then(function (data) {
                console.log(data);
                // localStorage.setItem('CreatedORGID', data.data.organizationID);
                __WEBPACK_IMPORTED_MODULE_3__routes__["Router"].pushRoute('/addNewUser2/' + data.data.organizationID);
            }).catch(function (error) {
                console.log('Error in saving organization', error);
            });
        };

        _this.maintainState = function (event) {
            var key = event.target.id;
            var val = event.target.value;
            if (key === 'cityID' || key === 'stateID' || key === 'countryID' || key === 'phone' || key === 'subscriptionID') val = parseInt(val);
            // if (key === 'zip') 
            //   val = null;
            _this.setState(function () {
                return _defineProperty({}, key, val);
            });
        };

        _this.validateForm = function () {
            if (_this.state.organization_Name && _this.state.stateID && _this.state.countryID && _this.state.subscription_startDate) {

                _this.setState(function () {
                    return {
                        validForm: true
                    };
                });
            } else {
                _this.setState(function () {
                    return {
                        validForm: false
                    };
                });
            }
        };

        _this.handlechange = function (event) {
            var name = event.target.name;
            var value = event.target.value;

            _this.setState(function () {
                return _defineProperty({}, name, value);
            }, function () {
                return _this.validateForm();
            });
        };

        _this.state = {
            organization_Name: '',
            add1: '',
            add2: '',
            cityID: 0,
            countryID: 0,
            stateID: 0,
            zip: null,
            contactPerson: '',
            email: '',
            phone: '',
            subscriptionID: 1,
            subscription_startDate: null,
            organization_status: true,
            validForm: false
        };
        return _this;
    }

    _createClass(AddNewUser, [{
        key: 'getInitialProps',
        value: function getInitialProps() {}
    }, {
        key: 'componentWillMount',
        value: function componentWillMount() {}

        // Update state on change on value in input fields

    }, {
        key: 'render',
        value: function render() {

            return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                'div',
                {
                    className: 'jsx-1509634679',
                    __source: {
                        fileName: _jsxFileName,
                        lineNumber: 99
                    }
                },
                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__UI_kit_Sidebar__["a" /* default */], {
                    __source: {
                        fileName: _jsxFileName,
                        lineNumber: 100
                    }
                }),
                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                    'div',
                    {
                        className: 'jsx-1509634679' + ' ' + 'mainpage',
                        __source: {
                            fileName: _jsxFileName,
                            lineNumber: 101
                        }
                    },
                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                        'div',
                        {
                            className: 'jsx-1509634679',
                            __source: {
                                fileName: _jsxFileName,
                                lineNumber: 102
                            }
                        },
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                            'div',
                            {
                                className: 'jsx-1509634679' + ' ' + 'headerpart',
                                __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 103
                                }
                            },
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'h2',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 104
                                    }
                                },
                                'ADD NEW CUSTOMERS'
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'p',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 105
                                    }
                                },
                                'Logged in as Administrator-',
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'span',
                                    {
                                        className: 'jsx-1509634679' + ' ' + 'font-weight-bold',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 105
                                        }
                                    },
                                    'Clinton, S '
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('i', {
                                    className: 'jsx-1509634679' + ' ' + 'down',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 105
                                    }
                                })
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                            'div',
                            {
                                className: 'jsx-1509634679' + ' ' + 'wizard',
                                __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 107
                                }
                            },
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'a',
                                { href: '#', className: 'jsx-1509634679' + ' ' + 'current',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 108
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'span',
                                    {
                                        className: 'jsx-1509634679' + ' ' + 'badge',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 108
                                        }
                                    },
                                    '1'
                                ),
                                'Customer Details'
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'a',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 109
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'span',
                                    { href: '#', className: 'jsx-1509634679' + ' ' + 'nextBadge',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 109
                                        }
                                    },
                                    '2'
                                ),
                                'Add Users'
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'a',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 110
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'span',
                                    { href: '#', className: 'jsx-1509634679' + ' ' + 'badge',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 110
                                        }
                                    },
                                    ' '
                                )
                            )
                        )
                    ),
                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                        'div',
                        {
                            className: 'jsx-1509634679' + ' ' + 'bodypart',
                            __source: {
                                fileName: _jsxFileName,
                                lineNumber: 113
                            }
                        },
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                            'form',
                            { action: '#', onSubmit: this.postOrganization, onChange: this.maintainState, className: 'jsx-1509634679',
                                __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 114
                                }
                            },
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'fieldset',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 115
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'legend',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 116
                                        }
                                    },
                                    'General Info'
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 117
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'organization_Name', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 118
                                            }
                                        },
                                        'Customer Name'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'organization_Name',
                                        type: 'text',
                                        id: 'organization_Name',
                                        value: this.state.organization_name,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'maininputs',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 119
                                        }
                                    })
                                )
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'fieldset',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 129
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'legend',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 130
                                        }
                                    },
                                    'Address Info'
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 131
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'add1', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 132
                                            }
                                        },
                                        'Address Line 1'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'add1',
                                        type: 'text',
                                        id: 'add1',
                                        value: this.state.add1,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'maininputs',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 133
                                        }
                                    })
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 142
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'add2', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 143
                                            }
                                        },
                                        'Address Line 2'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'add2',
                                        type: 'text', id: 'add2',
                                        value: this.state.add2,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'maininputs',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 144
                                        }
                                    })
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 152
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'countryID', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 153
                                            }
                                        },
                                        'Country'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'select',
                                        { name: 'countryID', id: 'countryID', value: this.state.countryID, onChange: this.handlechange, className: 'jsx-1509634679' + ' ' + 'countrydropdown',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 154
                                            }
                                        },
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('option', { value: '', className: 'jsx-1509634679',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 155
                                            }
                                        }),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '1', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 156
                                                }
                                            },
                                            'India'
                                        ),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '2', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 157
                                                }
                                            },
                                            'IN'
                                        )
                                    )
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 160
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'stateID', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 161
                                            }
                                        },
                                        'State/Province'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'select',
                                        { name: 'stateID', id: 'stateID', value: this.state.stateID, onChange: this.handlechange, className: 'jsx-1509634679' + ' ' + 'statedropdown',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 162
                                            }
                                        },
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('option', { value: '', className: 'jsx-1509634679',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 163
                                            }
                                        }),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '1', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 164
                                                }
                                            },
                                            'Maha'
                                        ),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '2', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 165
                                                }
                                            },
                                            'Maharashtra'
                                        )
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'cityID', className: 'jsx-1509634679' + ' ' + 'citylabel',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 167
                                            }
                                        },
                                        'City'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'select',
                                        { name: 'cityID', id: 'cityID', value: this.state.cityID, onChange: this.handlechange, className: 'jsx-1509634679' + ' ' + 'citydropdown',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 168
                                            }
                                        },
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '1', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 169
                                                }
                                            },
                                            'Pune'
                                        ),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '2', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 170
                                                }
                                            },
                                            'Pun'
                                        )
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'zip', className: 'jsx-1509634679' + ' ' + 'secondarylabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 172
                                            }
                                        },
                                        'Postal Code'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'zip',
                                        type: 'text',
                                        value: this.state.zip
                                        // onChange={this.handlechange}
                                        , className: 'jsx-1509634679' + ' ' + 'postalcodeinput',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 173
                                        }
                                    })
                                )
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'fieldset',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 182
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'legend',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 183
                                        }
                                    },
                                    'Contact Info'
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 184
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'contactPerson', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 185
                                            }
                                        },
                                        'Contact Person'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'contactPerson',
                                        type: 'text',
                                        id: 'contactPerson',
                                        value: this.state.contactPerson,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'contactinfoinput',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 186
                                        }
                                    })
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 195
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'email', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 196
                                            }
                                        },
                                        'E-mail ID'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'email',
                                        type: 'email',
                                        id: 'email',
                                        value: this.state.email,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'contactinfoinput',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 197
                                        }
                                    }),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'phone', className: 'jsx-1509634679' + ' ' + 'secondarylabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 205
                                            }
                                        },
                                        'Phone'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', {
                                        name: 'phone',
                                        type: 'text',
                                        id: 'phone',
                                        value: this.state.phone,
                                        onChange: this.handlechange,
                                        className: 'jsx-1509634679' + ' ' + 'contactinfophoneinput',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 206
                                        }
                                    })
                                )
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'fieldset',
                                {
                                    className: 'jsx-1509634679',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 216
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'legend',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 217
                                        }
                                    },
                                    'Subscription Details'
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 218
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'subscriptionID', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 219
                                            }
                                        },
                                        'Select Subscription'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'select',
                                        { name: 'subscriptionID', id: 'subscriptionID', value: this.state.subscriptionID, onChange: this.handlechange, className: 'jsx-1509634679' + ' ' + 'subscriptiondropdown',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 220
                                            }
                                        },
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '1', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 221
                                                }
                                            },
                                            'Platinum'
                                        ),
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '2', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 222
                                                }
                                            },
                                            'Gold'
                                        )
                                    )
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 225
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'duration', className: 'jsx-1509634679' + ' ' + 'mainlabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 226
                                            }
                                        },
                                        'Duration'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'select',
                                        { name: 'duration', className: 'jsx-1509634679' + ' ' + 'durationdropdown',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 227
                                            }
                                        },
                                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                            'option',
                                            { value: '1', className: 'jsx-1509634679',
                                                __source: {
                                                    fileName: _jsxFileName,
                                                    lineNumber: 228
                                                }
                                            },
                                            '1 Year'
                                        )
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'label',
                                        { htmlFor: 'subscription_startDate', className: 'jsx-1509634679' + ' ' + 'secondarylabels',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 230
                                            }
                                        },
                                        'Starts from'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement('input', { name: 'subscription_startDate', type: 'date', id: 'subscription_startDate', value: this.state.subscription_startDate, onChange: this.handlechange, className: 'jsx-1509634679' + ' ' + 'starts-from',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 231
                                        }
                                    })
                                )
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                'div',
                                {
                                    className: 'jsx-1509634679' + ' ' + 'buttons',
                                    __source: {
                                        fileName: _jsxFileName,
                                        lineNumber: 234
                                    }
                                },
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 235
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'button',
                                        { type: 'submit', disabled: !this.state.validForm, className: 'jsx-1509634679' + ' ' + 'primarybutton',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 236
                                            }
                                        },
                                        'Save & Next'
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'button',
                                        { type: 'reset', className: 'jsx-1509634679' + ' ' + 'secondarybutton',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 237
                                            }
                                        },
                                        'Reset'
                                    )
                                ),
                                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                    'p',
                                    {
                                        className: 'jsx-1509634679',
                                        __source: {
                                            fileName: _jsxFileName,
                                            lineNumber: 239
                                        }
                                    },
                                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                        'button',
                                        { disabled: !this.state.validForm, className: 'jsx-1509634679' + ' ' + 'secondarybutton',
                                            __source: {
                                                fileName: _jsxFileName,
                                                lineNumber: 240
                                            }
                                        },
                                        'Cancel'
                                    )
                                )
                            )
                        )
                    )
                ),
                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
                    styleId: '1509634679',
                    css: '.mainpage.jsx-1509634679{height:100%;margin-left:15%;width:85%;}.headerpart.jsx-1509634679{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:98%;padding:10px;background-color:#ffffff;border-bottom-style:solid;border-width:1px;border-bottom-color:lightgrey;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:5.2%;}.headerpart.jsx-1509634679 h2.jsx-1509634679{font-size:16px;margin:0;color:#666666;font-weight:bold;}.headerpart.jsx-1509634679 p.jsx-1509634679{font-size:11px;margin:0;}.headerpart.jsx-1509634679 p.jsx-1509634679 span.jsx-1509634679{font-weight:bold;}.headerpart.jsx-1509634679 p.jsx-1509634679 i.jsx-1509634679{border:solid black;border-width:0 3px 3px 0;display:inline-block;padding:3px;}.headerpart.jsx-1509634679 p.jsx-1509634679 .down.jsx-1509634679{-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg);-webkit-transform:rotate(45deg);}.wizard.jsx-1509634679{margin:20px;}.wizard.jsx-1509634679 a.jsx-1509634679{padding:10px 12px 10px;margin-right:5px;background:#bbcede;position:relative;display:inline-block;width:171px;cursor:pointer;font-size:16px;-webkit-text-decoration:none;text-decoration:none;}.wizard.jsx-1509634679 a.jsx-1509634679:last-child{width:calc(100% - 366px);backbackground:#d0dbe5;}.wizard.jsx-1509634679 a.jsx-1509634679:before{width:0;height:0;border-top:20px inset transparent;border-bottom:20px inset transparent;border-left:20px solid rgb(236,236,236);position:absolute;content:"";top:0;left:0;}.wizard.jsx-1509634679 a.jsx-1509634679:after{width:0;height:0;border-top:20px inset transparent;border-bottom:20px inset transparent;border-left:20px solid rgb(187,206,221);position:absolute;content:"";top:0;right:-20px;z-index:2;}.wizard.jsx-1509634679 a.jsx-1509634679:first-child.jsx-1509634679:before,.wizard.jsx-1509634679 a.jsx-1509634679:last-child.jsx-1509634679:after{border:none;}.wizard.jsx-1509634679 a.jsx-1509634679:first-child{-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px;}.wizard.jsx-1509634679 a.jsx-1509634679:last-child{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0;}.wizard.jsx-1509634679 .badge.jsx-1509634679{border-radius:4px;margin:0 5px 0 18px;position:relative;top:-1px;color:#747474;background-color:#fcfcfc;display:inline-block;width:23px;height:23px;text-align:center;}.wizard.jsx-1509634679 .nextBadge.jsx-1509634679{border-radius:4px;margin:0 5px 0 18px;position:relative;top:-1px;color:#666666;background-color:#f6f6f6;display:inline-block;width:23px;height:23px;text-align:center;}.wizard.jsx-1509634679 a.jsx-1509634679:first-child .badge.jsx-1509634679{margin-left:0;}.wizard.jsx-1509634679 .current.jsx-1509634679{background:#dd4852;color:#fff;}.wizard.jsx-1509634679 .current.jsx-1509634679:after{border-left-color:#dd4852;}.bodypart.jsx-1509634679{margin:20px;}legend.jsx-1509634679{font-size:13px;line-height:20px;margin-bottom:0;width:auto;font-weight:bold;}fieldset.jsx-1509634679{border:1px solid #d0dbe5;padding:10px 21px;}select.jsx-1509634679>option[value=""].jsx-1509634679{display:none;}.buttons.jsx-1509634679{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;margin-top:28px;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;}.bodypart.jsx-1509634679 p.jsx-1509634679{margin-bottom:10px;}.mainlabels.jsx-1509634679{width:140px;margin-right:8px;font-size:13px;display:inline-block;}.secondarylabels.jsx-1509634679{width:85px;margin-right:8px;margin-left:50px;font-size:13px;display:inline-block;}.citylabel.jsx-1509634679{margin-right:10px;margin-left:50px;width:50px;font-size:13px;display:inline-block;}.maininputs.jsx-1509634679{width:393px;font-size:13px;height:26px;border-width:1px;padding:0;}.countrydropdown.jsx-1509634679{width:229px;font-size:13px;height:28px;}.statedropdown.jsx-1509634679{width:123px;font-size:13px;height:28px;}.citydropdown.jsx-1509634679{width:163px;font-size:13px;height:28px;}.contactinfoinput.jsx-1509634679{width:332px;font-size:13px;height:26px;border-width:1px;padding:0;}.contactinfophoneinput.jsx-1509634679{width:163px;font-size:13px;height:26px;border-width:1px;padding:0;}.postalcodeinput.jsx-1509634679{width:111px;font-size:13px;height:26px;border-width:1px;padding:0;}.subscriptiondropdown.jsx-1509634679{width:163px;font-size:13px;height:28px;}.durationdropdown.jsx-1509634679{width:123px;font-size:13px;height:28px;}.starts-from.jsx-1509634679{width:130px;font-size:13px;height:26px;border-width:1px;padding:0;}.primarybutton.jsx-1509634679{margin:0 13px 0 0;padding:0;height:36px;cursor:pointer;width:127px;color:white;background-color:rgb(50,101,153);font-size:14px;}.secondarybutton.jsx-1509634679{margin:0 13px 0 0;padding:0;height:36px;cursor:pointer;width:127px;color:rgb(50,101,153);background-color:white;border:1px solid rgb(50,101,153);font-size:14px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudHNcXEFkZE5ld1VzZXJcXGluZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXFQb0IsQUFHNkIsQUFPQyxBQWNFLEFBUUEsQUFLRSxBQUlFLEFBTUssQUFLWixBQUlXLEFBV0UsQUFJakIsQUFXQSxBQWFJLEFBSXNCLEFBS0EsQUFLaEIsQUFZQSxBQVlKLEFBR0ssQUFJTyxBQUlkLEFBSUcsQUFRVSxBQUlaLEFBSUEsQUFNTSxBQUlQLEFBT0QsQUFRTyxBQVFOLEFBUUEsQUFNQSxBQU1BLEFBTUEsQUFRQSxBQVFBLEFBUUEsQUFNQSxBQU1BLEFBUU0sQUFXQSxRQTlNVCxBQVdBLEdBbUdRLENBbExELEFBaURwQixBQTJDQSxBQWlEQSxBQThCcUIsQUF1QkYsQUFRQSxBQU1BLEFBTUEsQUFNQSxBQVFBLEFBUUEsQUFRQSxBQU1BLEFBTUEsQ0FuR25CLENBM0JBLENBN0dhLEFBUUEsQUFvSFEsRUEvR3JCLEFBbUNzQyxBQVdBLENBMEJkLEFBWUEsQUFvRUgsQUE4RVAsQUFXQSxDQTdPZSxBQStGZCxBQWtDZixJQWxIcUIsQ0EvQkgsQUFRbEIsQ0FrQzJCLEFBeUZMLENBaEJ0QixDQTBEZ0IsQUFRQSxBQU1BLEFBTUEsQUFNQSxBQVFBLEFBUUEsQUFRQSxBQU1BLEFBTUEsQ0FoUUYsQUFrTE8sQUFzRkwsQUFXQSxDQXhHRyxDQXRDbkIsRUFZb0IsRUFsRGUsQUFLQSxDQXNGcEIsR0F6TGYsQUFxQnFCLEFBb0ZDLEFBWUEsQ0E2RUQsQUFRckIsQUFNQSxBQU1BLEFBTXFCLEFBUUEsQUFRQSxBQVFyQixBQU1BLEFBTXFCLENBNU1FLEFBb05KLEFBV0EsR0EzSG5CLENBbkh5QixBQXNJQSxDQU9OLENBUUEsRUEzSG5CLEFBa0ZlLEdBN0UwQixBQVdBLElBekR6QyxBQW1QZ0IsQUFXQSxDQTFLSCxBQVlBLEFBNkVDLEFBMEJBLEFBUUEsQUFRQSxBQW9CQSxHQTVNUSxBQTZGRCxDQWlDSSxDQVFBLElBckpULEFBeURzQixBQUtBLEFBT3BCLEFBWUEsQUFxRGxCLENBd0JBLEFBMEJBLEFBUUEsQUFRQSxBQW9CQSxDQVFnQixBQVdZLE9BaFJkLEFBMEpNLEVBWnBCLENBNUdBLEFBZXlCLEVBc0RJLEFBWUEsQUFtSlUsRUF2RnZDLENBUUEsRUF0TGlCLEFBb0NtQixJQTJCVSxBQVdBLENBc01uQixDQXRITyxDQWhFbEMsQUFLQSxNQTlGNkIsQ0FnRGIsTUFzRFMsQUFZQSxNQWpFTixFQW9OQSxBQVdvQixJQTVPdkMsTUFuQzhCLEdBaURYLEFBcURKLEFBWUEsRUFtSmYsQ0F2TXNCLEFBV0EsUUE4Qk4sQUFZQSxJQWpFUyxLQThOTixDQWpOSixBQVdBLEVBekVNLEFBdUdDLEFBWUEsU0FwRFosQUFXQSxHQXNNVixHQWhOVyxBQVdLLEVBMUVrQixDQXVHbEMsQUFZQSxJQW5EQSxLQVdjLFVBQ2QsS0EzQkEsS0FoRHVCLFVBc0p2QixtRkFySmtDLG1IQUNsQixZQUNoQiIsImZpbGUiOiJjb21wb25lbnRzXFxBZGROZXdVc2VyXFxpbmRleC5qcyIsInNvdXJjZVJvb3QiOiJDOi9Vc2Vycy9WQXJ1bi9EZXNrdG9wL2xhdGVzdC9wb2x5bWVyLXdlYmFwcC9wb2x5bWVyLXYyL1BvbHltZXItUmVhY3QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcydcclxuaW1wb3J0IHtSb3V0ZXJ9IGZyb20gJy4uLy4uL3JvdXRlcydcclxuaW1wb3J0IHtjb25uZWN0fSBmcm9tICdyZWFjdC1yZWR1eCdcclxuaW1wb3J0IHsgYmluZEFjdGlvbkNyZWF0b3JzIH0gZnJvbSAncmVkdXgnXHJcbmltcG9ydCB7ZmV0Y2hHaXRIdWJSZXBvcywgZmV0Y2hHaXRIdWJVc2VyfSBmcm9tICcuL3JlcG9MaXN0QWN0aW9uQ3JlYXRvcidcclxuaW1wb3J0IHsgUHJpbWFyeUJ1dHRvbiB9IGZyb20gJy4uLy4uL1VJLWtpdC9CdXR0b25zJ1xyXG5pbXBvcnQgTWFpbkxheW91dCBmcm9tICcuLi8uLi9VSS1raXQvTWFpbkxheW91dCdcclxuaW1wb3J0IHtJbnB1dEJveH0gZnJvbSAnLi4vLi4vVUkta2l0L0lucHV0VHlwZXMnXHJcbmltcG9ydCBUaXRsZSBmcm9tICcuL3RpdGxlJ1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi8uLi9VSS1raXQvU2lkZWJhcidcclxuXHJcbmNsYXNzIEFkZE5ld1VzZXIgZXh0ZW5kcyBDb21wb25lbnR7XHJcblxyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9wcywgY29udGV4dCkge1xyXG4gICAgc3VwZXIocHJvcHMsIGNvbnRleHQpXHJcbiAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICBvcmdhbml6YXRpb25fTmFtZTogJycsXHJcbiAgICAgIGFkZDE6ICcnLFxyXG4gICAgICBhZGQyOiAnJyxcclxuICAgICAgY2l0eUlEOiAwLFxyXG4gICAgICBjb3VudHJ5SUQ6IDAsXHJcbiAgICAgIHN0YXRlSUQ6IDAsXHJcbiAgICAgIHppcDogbnVsbCxcclxuICAgICAgY29udGFjdFBlcnNvbjogJycsXHJcbiAgICAgIGVtYWlsOiAnJyxcclxuICAgICAgcGhvbmU6ICcnLFxyXG4gICAgICBzdWJzY3JpcHRpb25JRDogMSxcclxuICAgICAgc3Vic2NyaXB0aW9uX3N0YXJ0RGF0ZTogbnVsbCxcclxuICAgICAgb3JnYW5pemF0aW9uX3N0YXR1czogdHJ1ZSxcclxuICAgICAgdmFsaWRGb3JtOiBmYWxzZVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcG9zdE9yZ2FuaXphdGlvbiA9IChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnNvbGUubG9nKHRoaXMuc3RhdGUpO1xyXG4gICAgYXhpb3MucG9zdCgnaHR0cDovL2xvY2FsaG9zdDoxMzM3L29yZ2FuaXphdGlvbicsICh0aGlzLnN0YXRlKSlcclxuICAgICAgLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgLy8gbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ0NyZWF0ZWRPUkdJRCcsIGRhdGEuZGF0YS5vcmdhbml6YXRpb25JRCk7XHJcbiAgICAgICAgUm91dGVyLnB1c2hSb3V0ZSgnL2FkZE5ld1VzZXIyLycgKyBkYXRhLmRhdGEub3JnYW5pemF0aW9uSUQpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyb3IgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciBpbiBzYXZpbmcgb3JnYW5pemF0aW9uJywgZXJyb3IpO1xyXG4gICAgICB9KVxyXG4gIH1cclxuXHJcbiAgbWFpbnRhaW5TdGF0ZSA9IGV2ZW50ID0+IHtcclxuICAgIGxldCBrZXkgPSBldmVudC50YXJnZXQuaWQ7XHJcbiAgICBsZXQgdmFsID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgaWYgKGtleSA9PT0gJ2NpdHlJRCcgfHwga2V5ID09PSAnc3RhdGVJRCcgfHwga2V5ID09PSAnY291bnRyeUlEJyB8fCBrZXkgPT09ICdwaG9uZScgfHwga2V5ID09PSAnc3Vic2NyaXB0aW9uSUQnKVxyXG4gICAgICB2YWwgPSBwYXJzZUludCh2YWwpO1xyXG4gICAgLy8gaWYgKGtleSA9PT0gJ3ppcCcpIFxyXG4gICAgLy8gICB2YWwgPSBudWxsO1xyXG4gICAgdGhpcy5zZXRTdGF0ZSgoKSA9PiB7XHJcbiAgICAgIHJldHVybiAoe1xyXG4gICAgICAgIFtrZXldOiB2YWxcclxuICAgICAgfSlcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBnZXRJbml0aWFsUHJvcHMoKSB7XHJcblxyXG4gIH1cclxuXHJcbiAgY29tcG9uZW50V2lsbE1vdW50KCkge1xyXG4gIH1cclxuXHJcbiAgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgaWYgKHRoaXMuc3RhdGUub3JnYW5pemF0aW9uX05hbWUgJiYgdGhpcy5zdGF0ZS5zdGF0ZUlEICYmIHRoaXMuc3RhdGUuY291bnRyeUlEICYmIHRoaXMuc3RhdGUuc3Vic2NyaXB0aW9uX3N0YXJ0RGF0ZSkge1xyXG4gICAgICAgXHJcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSgoKSA9PiAoe1xyXG4gICAgICAgICAgICB2YWxpZEZvcm06IHRydWUgIFxyXG4gICAgICAgICAgfSkpXHJcbiAgICB9ZWxzZSB7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoKCkgPT4gKHtcclxuICAgICAgICB2YWxpZEZvcm06IGZhbHNlICBcclxuICAgICAgfSkpICAgICBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIFVwZGF0ZSBzdGF0ZSBvbiBjaGFuZ2Ugb24gdmFsdWUgaW4gaW5wdXQgZmllbGRzXHJcbiAgaGFuZGxlY2hhbmdlID0gKGV2ZW50KSA9PiB7XHJcbiAgICBsZXQgbmFtZSA9IGV2ZW50LnRhcmdldC5uYW1lO1xyXG4gICAgbGV0IHZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgXHJcbiAgICB0aGlzLnNldFN0YXRlKCgpID0+ICh7XHJcbiAgICAgIFtuYW1lXTogdmFsdWVcclxuICAgIH0pLCAoKT0+dGhpcy52YWxpZGF0ZUZvcm0oKSApXHJcbiAgfVxyXG5cclxuICBcclxuXHJcbiAgcmVuZGVyKCkge1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1haW5wYWdlXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcnBhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDI+QUREIE5FVyBDVVNUT01FUlM8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPkxvZ2dlZCBpbiBhcyBBZG1pbmlzdHJhdG9yLTxzcGFuIGNsYXNzTmFtZT1cImZvbnQtd2VpZ2h0LWJvbGRcIj5DbGludG9uLCBTIDwvc3Bhbj48aSBjbGFzc05hbWU9XCJkb3duXCI+PC9pPjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3aXphcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJjdXJyZW50XCIgaHJlZj1cIiNcIj48c3BhbiBjbGFzc05hbWU9XCJiYWRnZVwiPjE8L3NwYW4+Q3VzdG9tZXIgRGV0YWlsczwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8YT48c3BhbiBjbGFzc05hbWU9XCJuZXh0QmFkZ2VcIiBocmVmPVwiI1wiPjI8L3NwYW4+QWRkIFVzZXJzPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhPjxzcGFuIGNsYXNzTmFtZT1cImJhZGdlXCIgaHJlZj1cIiNcIj4gPC9zcGFuPjwvYT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib2R5cGFydFwiPlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gYWN0aW9uPVwiI1wiIG9uU3VibWl0PXt0aGlzLnBvc3RPcmdhbml6YXRpb259IG9uQ2hhbmdlPXt0aGlzLm1haW50YWluU3RhdGV9ID5cclxuICAgICAgICAgICAgICAgICAgICA8ZmllbGRzZXQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsZWdlbmQ+R2VuZXJhbCBJbmZvPC9sZWdlbmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1haW5sYWJlbHNcIiBodG1sRm9yPVwib3JnYW5pemF0aW9uX05hbWVcIj5DdXN0b21lciBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYWluaW5wdXRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwib3JnYW5pemF0aW9uX05hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZ2FuaXphdGlvbl9OYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS5vcmdhbml6YXRpb25fbmFtZX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZmllbGRzZXQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGZpZWxkc2V0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGVnZW5kPkFkZHJlc3MgSW5mbzwvbGVnZW5kPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYWlubGFiZWxzXCIgaHRtbEZvcj1cImFkZDFcIj5BZGRyZXNzIExpbmUgMTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWFpbmlucHV0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkZDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImFkZDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmFkZDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYWlubGFiZWxzXCIgaHRtbEZvcj1cImFkZDJcIj5BZGRyZXNzIExpbmUgMjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYWluaW5wdXRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBpZD1cImFkZDJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmFkZDJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYWlubGFiZWxzXCIgaHRtbEZvcj1cImNvdW50cnlJRFwiPkNvdW50cnk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJjb3VudHJ5ZHJvcGRvd25cIiBuYW1lPVwiY291bnRyeUlEXCIgIGlkPVwiY291bnRyeUlEXCIgdmFsdWU9e3RoaXMuc3RhdGUuY291bnRyeUlEfSBvbkNoYW5nZT17dGhpcy5oYW5kbGVjaGFuZ2V9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMVwiPkluZGlhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjJcIj5JTjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWFpbmxhYmVsc1wiIGh0bWxGb3I9XCJzdGF0ZUlEXCI+U3RhdGUvUHJvdmluY2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzdGF0ZWRyb3Bkb3duXCIgbmFtZT1cInN0YXRlSURcIiAgaWQ9XCJzdGF0ZUlEXCIgdmFsdWU9e3RoaXMuc3RhdGUuc3RhdGVJRH0gb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjFcIj5NYWhhPC9vcHRpb24+IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIyXCI+TWFoYXJhc2h0cmE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNpdHlsYWJlbFwiIGh0bWxGb3I9XCJjaXR5SURcIj5DaXR5PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiY2l0eWRyb3Bkb3duXCIgbmFtZT1cImNpdHlJRFwiICBpZD1cImNpdHlJRFwiIHZhbHVlPXt0aGlzLnN0YXRlLmNpdHlJRH0gb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMVwiPlB1bmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMlwiPlB1bjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2Vjb25kYXJ5bGFiZWxzXCIgaHRtbEZvcj1cInppcFwiPlBvc3RhbCBDb2RlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBvc3RhbGNvZGVpbnB1dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInppcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnppcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNoYW5nZT17dGhpcy5oYW5kbGVjaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9maWVsZHNldD5cclxuICAgICAgICAgICAgICAgICAgICA8ZmllbGRzZXQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsZWdlbmQ+Q29udGFjdCBJbmZvPC9sZWdlbmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1haW5sYWJlbHNcIiBodG1sRm9yPVwiY29udGFjdFBlcnNvblwiPkNvbnRhY3QgUGVyc29uPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb250YWN0aW5mb2lucHV0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29udGFjdFBlcnNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbnRhY3RQZXJzb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmNvbnRhY3RQZXJzb259IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZWNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWFpbmxhYmVsc1wiIGh0bWxGb3I9XCJlbWFpbFwiPkUtbWFpbCBJRDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGFjdGluZm9pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZWNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2Vjb25kYXJ5bGFiZWxzXCIgaHRtbEZvcj1cInBob25lXCI+UGhvbmU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGFjdGluZm9waG9uZWlucHV0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBob25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS5waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVjaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9maWVsZHNldD5cclxuICAgICAgICAgICAgICAgICAgICA8ZmllbGRzZXQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsZWdlbmQ+U3Vic2NyaXB0aW9uIERldGFpbHM8L2xlZ2VuZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWFpbmxhYmVsc1wiIGh0bWxGb3I9XCJzdWJzY3JpcHRpb25JRFwiPlNlbGVjdCBTdWJzY3JpcHRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzdWJzY3JpcHRpb25kcm9wZG93blwiIG5hbWU9XCJzdWJzY3JpcHRpb25JRFwiICBpZD1cInN1YnNjcmlwdGlvbklEXCIgdmFsdWU9e3RoaXMuc3RhdGUuc3Vic2NyaXB0aW9uSUR9IG9uQ2hhbmdlPXt0aGlzLmhhbmRsZWNoYW5nZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjFcIj5QbGF0aW51bTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIyXCI+R29sZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWFpbmxhYmVsc1wiIGh0bWxGb3I9XCJkdXJhdGlvblwiPkR1cmF0aW9uPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZHVyYXRpb25kcm9wZG93blwiIG5hbWU9XCJkdXJhdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIxXCI+MSBZZWFyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzZWNvbmRhcnlsYWJlbHNcIiBodG1sRm9yPVwic3Vic2NyaXB0aW9uX3N0YXJ0RGF0ZVwiPlN0YXJ0cyBmcm9tPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJzdGFydHMtZnJvbVwiIG5hbWU9XCJzdWJzY3JpcHRpb25fc3RhcnREYXRlXCIgdHlwZT1cImRhdGVcIiAgaWQ9XCJzdWJzY3JpcHRpb25fc3RhcnREYXRlXCIgdmFsdWU9e3RoaXMuc3RhdGUuc3Vic2NyaXB0aW9uX3N0YXJ0RGF0ZX0gb25DaGFuZ2U9e3RoaXMuaGFuZGxlY2hhbmdlfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9maWVsZHNldD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1dHRvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInByaW1hcnlidXR0b25cIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9eyF0aGlzLnN0YXRlLnZhbGlkRm9ybX0gPlNhdmUgJiBOZXh0PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNlY29uZGFyeWJ1dHRvblwiIHR5cGU9XCJyZXNldFwiPlJlc2V0PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNlY29uZGFyeWJ1dHRvblwiIGRpc2FibGVkPXshdGhpcy5zdGF0ZS52YWxpZEZvcm19PkNhbmNlbDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxzdHlsZSBqc3g+e2BcclxuICAgICAgICAgIC5tYWlucGFnZSB7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTUlO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDg1JTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLyogVG9wIGhlYWRlciAqL1xyXG4gICAgICAgICAgICAuaGVhZGVycGFydCB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDk4JTtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItd2lkdGg6IDFweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b20tY29sb3I6IGxpZ2h0Z3JleTtcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDUuMiU7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8qIEhlYWRpbmcgKi9cclxuICAgICAgICAgICAgLmhlYWRlcnBhcnQgaDIge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICM2NjY2NjY7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLyogTG9nZ2VkIGluIGFzICovXHJcbiAgICAgICAgICAgIC5oZWFkZXJwYXJ0IHAge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuaGVhZGVycGFydCBwIHNwYW4ge1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC5oZWFkZXJwYXJ0IHAgaSB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IHNvbGlkIGJsYWNrO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXdpZHRoOiAwIDNweCAzcHggMDtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDNweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuaGVhZGVycGFydCBwIC5kb3duIHtcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAud2l6YXJkIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMjBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLndpemFyZCBhIHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTJweCAxMHB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjYmJjZWRlO1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDE3MXB4O1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC53aXphcmQgYTpsYXN0LWNoaWxkIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSAzNjZweCk7XHJcbiAgICAgICAgICAgICAgICBiYWNrYmFja2dyb3VuZDogI2QwZGJlNTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAud2l6YXJkIGE6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAwO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAwO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcDogMjBweCBpbnNldCB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDIwcHggaW5zZXQgdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItbGVmdDogMjBweCBzb2xpZCByZ2IoMjM2LCAyMzYsIDIzNik7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgICAgICAgICAgdG9wOiAwO1xyXG4gICAgICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAud2l6YXJkIGE6YWZ0ZXIge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDA7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItdG9wOiAyMHB4IGluc2V0IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMjBweCBpbnNldCB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1sZWZ0OiAyMHB4IHNvbGlkIHJnYigxODcsIDIwNiwgMjIxKTtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICB0b3A6IDA7XHJcbiAgICAgICAgICAgICAgICByaWdodDogLTIwcHg7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiAyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC53aXphcmQgYTpmaXJzdC1jaGlsZDpiZWZvcmUsXHJcbiAgICAgICAgICAgIC53aXphcmQgYTpsYXN0LWNoaWxkOmFmdGVyIHtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLndpemFyZCBhOmZpcnN0LWNoaWxkIHtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNHB4IDAgMCA0cHg7XHJcbiAgICAgICAgICAgICAgICAtbW96LWJvcmRlci1yYWRpdXM6IDRweCAwIDAgNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHggMCAwIDRweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAud2l6YXJkIGE6bGFzdC1jaGlsZCB7XHJcbiAgICAgICAgICAgICAgICAtd2Via2l0LWJvcmRlci1yYWRpdXM6IDAgNHB4IDRweCAwO1xyXG4gICAgICAgICAgICAgICAgLW1vei1ib3JkZXItcmFkaXVzOiAwIDRweCA0cHggMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMCA0cHggNHB4IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLndpemFyZCAuYmFkZ2Uge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwIDVweCAwIDE4cHg7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICB0b3A6IC0xcHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzc0NzQ3NDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2ZjZmM7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMjNweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMjNweDtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAud2l6YXJkIC5uZXh0QmFkZ2Uge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwIDVweCAwIDE4cHg7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICB0b3A6IC0xcHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzY2NjY2NjtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmNmY2ZjY7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMjNweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMjNweDtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAud2l6YXJkIGE6Zmlyc3QtY2hpbGQgLmJhZGdlIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC53aXphcmQgLmN1cnJlbnQge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2RkNDg1MjtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC53aXphcmQgLmN1cnJlbnQ6YWZ0ZXIge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWxlZnQtY29sb3I6ICNkZDQ4NTI7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5ib2R5cGFydCB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDIwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxlZ2VuZCB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMjBweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogYXV0bztcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkOyAgIFxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBmaWVsZHNldCB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZDBkYmU1O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMTBweCAyMXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNlbGVjdCA+IG9wdGlvblt2YWx1ZT1cIlwiXSB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuYnV0dG9ucyB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMjhweDtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmJvZHlwYXJ0IHAge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLm1haW5sYWJlbHMge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5zZWNvbmRhcnlsYWJlbHMge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDg1cHg7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDhweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY2l0eWxhYmVsIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5tYWluaW5wdXRzIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAzOTNweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMjZweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmNvdW50cnlkcm9wZG93biB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMjI5cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5zdGF0ZWRyb3Bkb3duIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMjNweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMjhweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmNpdHlkcm9wZG93biB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTYzcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5jb250YWN0aW5mb2lucHV0IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAzMzJweDtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMjZweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmNvbnRhY3RpbmZvcGhvbmVpbnB1dCB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTYzcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDI2cHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItd2lkdGg6IDFweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5wb3N0YWxjb2RlaW5wdXQge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDExMXB4O1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAyNnB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuc3Vic2NyaXB0aW9uZHJvcGRvd24ge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDE2M3B4O1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuZHVyYXRpb25kcm9wZG93biB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTIzcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5zdGFydHMtZnJvbSB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTMwcHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDI2cHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItd2lkdGg6IDFweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5wcmltYXJ5YnV0dG9uIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMCAxM3B4IDAgMDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDM2cHg7XHJcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTI3cHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoNTAsIDEwMSwgMTUzKTtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnNlY29uZGFyeWJ1dHRvbiB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAgMTNweCAwIDA7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAzNnB4O1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEyN3B4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHJnYig1MCwgMTAxLCAxNTMpO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoNTAsIDEwMSwgMTUzKTtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICBgfTwvc3R5bGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbn1cclxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIGZldGNoR2l0SHViUmVwb3M6IGJpbmRBY3Rpb25DcmVhdG9ycyhmZXRjaEdpdEh1YlJlcG9zLCBkaXNwYXRjaCksXHJcbiAgICBmZXRjaEdpdEh1YlVzZXI6IGJpbmRBY3Rpb25DcmVhdG9ycyhmZXRjaEdpdEh1YlVzZXIsIGRpc3BhdGNoKVxyXG4gIH1cclxufVxyXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgcmVwb0RhdGE6IHN0YXRlLmZldGNoUmVwby5yZXBvRGF0YSxcclxuICAgIHVzZXJEYXRhOiBzdGF0ZS5Vc2VySW5mby51c2VySW5mb1xyXG4gIH1cclxufVxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcyxtYXBEaXNwYXRjaFRvUHJvcHMpKEFkZE5ld1VzZXIpXHJcbiJdfQ== */\n/*@ sourceURL=components\\AddNewUser\\index.js */'
                })
            );
        }
    }, {
        key: '__reactstandin__regenerateByEval',
        value: function __reactstandin__regenerateByEval(key, code) {
            this[key] = eval(code);
        }
    }]);

    return AddNewUser;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
    return {
        fetchGitHubRepos: Object(__WEBPACK_IMPORTED_MODULE_5_redux__["bindActionCreators"])(__WEBPACK_IMPORTED_MODULE_6__repoListActionCreator__["a" /* fetchGitHubRepos */], dispatch),
        fetchGitHubUser: Object(__WEBPACK_IMPORTED_MODULE_5_redux__["bindActionCreators"])(__WEBPACK_IMPORTED_MODULE_6__repoListActionCreator__["b" /* fetchGitHubUser */], dispatch)
    };
};
var mapStateToProps = function mapStateToProps(state) {
    return {
        repoData: state.fetchRepo.repoData,
        userData: state.UserInfo.userInfo
    };
};

var _default = Object(__WEBPACK_IMPORTED_MODULE_4_react_redux__["connect"])(mapStateToProps, mapDispatchToProps)(AddNewUser);

/* harmony default export */ __webpack_exports__["a"] = (_default);
;

(function () {
    var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(AddNewUser, 'AddNewUser', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/AddNewUser/index.js');
    reactHotLoader.register(mapDispatchToProps, 'mapDispatchToProps', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/AddNewUser/index.js');
    reactHotLoader.register(mapStateToProps, 'mapStateToProps', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/AddNewUser/index.js');
    reactHotLoader.register(_default, 'default', 'C:/Users/VArun/Desktop/latest/polymer-webapp/polymer-v2/Polymer-React/components/AddNewUser/index.js');
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.2011a78b2d0f14c09a37.hot-update.js.map