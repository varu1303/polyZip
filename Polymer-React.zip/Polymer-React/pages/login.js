import React from 'react'
import withRedux from 'next-redux-wrapper'

import Login from '../components/Login'
import { initStore } from '../libs/store'


class Auth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  render() {
    return (
        <Login />
    )
  }
}

export default withRedux(initStore, null)(Auth)
