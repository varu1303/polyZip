import React from 'react'
import styled from 'styled-components'

const Title = styled.h2`
  color: #ccc;
  font-size: 40px;
`
export default (props) => {
  console.log(props)
  return <Title>{props.title}</Title>
}
