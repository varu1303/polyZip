import React, { Component } from 'react'
import axios from 'axios'
import Auxiliary from '../../components/HOC/Auxiliary'


class Profile extends Component {
    constructor(props, context) {
        super(props, context)
        this.state = {
          gender: this.props.gender
        }
    }
    render () {
        const genderImg = (this.state.gender == "Female") ? "../../static/img/f-icon.png" : "../../static/img/m-icon.png";
        return (
            <Auxiliary>
                <div className="users">
                            <div className="userprofile">
                                <div className="userinfo">
                                    <img src={genderImg} height="31px" width="33px" />
                                    <div className="name_role">
                                        <p className="username">{this.props.name}</p>
                                        <p className="user-role">{this.props.role}</p>
                                    </div>
                                </div>
                                <p className="user-email">{this.props.email}</p>
                            </div>
                            <div className="editicon">
                                <button className="editButton"></button>
                            </div>
                        </div>
                
                <style jsx>{`
                    .users {
                        display: inline-block;
                        width: 249px;
                        padding: 10px;
                        margin-right: 10px;
                        margin-bottom: 10px;
                        background-color: white;
                        height: 79px;
                    }
                                
                    .userinfo {
                        display: flex;
                    }
                    
                    .name_role {
                        margin-left: 5px;
                    }
                    
                    .name_role  p {
                        margin: 0;
                    }
        
                    .username {
                        font-size: 13px;
                        font-weight: bold;
                        margin: 0;
                    }
                    
                    .user-role {
                        font-size: 11px;
                        margin: 0;
                    }
                    .user-email {
                        margin: 15px 0;
                        font-size: 13px;
                    }
        
                    .userprofile {
                        float: left;
                        border-right-style: solid;
                        border-width: 2px;
                        border-color: rgb(246, 246, 246);
                        width: 204px;
                    }
                    
                    .editicon {
                        display: inline-block;
                        height: 79px;
                        width: 39px;
                    }

                    .editicon .editButton {
                        height: 17px;
                        width: 17px;
                        border: none;
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        cursor: pointer;
                        color: white;
                        margin: 30px 14px;
                    }
                `}</style>
            </Auxiliary>
        )
    }
}    

export default Profile;