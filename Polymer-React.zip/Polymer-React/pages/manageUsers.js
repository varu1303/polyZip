import React from 'react'
import withRedux from 'next-redux-wrapper'

import ManageUsers from '../components/ManageUsers'
import { initStore } from '../libs/store'


class ManageUsersAuth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  static async getInitialProps ({ req, query }) {
    return req
      ? { orgID: req.params.orgID }
      : { orgID: null }
    }

  render() {
    return (
        <ManageUsers orgID={this.props.orgID} />
    )
  }
}

export default withRedux(initStore, null)(ManageUsersAuth)
