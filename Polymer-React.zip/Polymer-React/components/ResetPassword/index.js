import React, { Component } from 'react'
import axios from 'axios'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import { PrimaryButton } from '../../UI-kit/Buttons'
import MainLayout from '../../UI-kit/MainLayout'
import {InputBox} from '../../UI-kit/InputTypes'
import Title from './title'
class ForgotPassword extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName: props.value,
      repoData: []
    }
  }
  getInitialProps() {

  }

  componentWillMount() {
  }

  render() {

    return (
      <MainLayout>
        <div className="head-box">
          <img src="../../static/img/predict-logo.png" alt="" />
        </div>
        <div className="container _resetBg">
          {/* <p className="text-center">Common-sense <b>Technology Solutions</b><br/>for Enterprise Data</p> */}
          <div className="_reset-box">
            <div className="logo">
              <img className="align-center" src="../../static/img/polymer-logo.png" alt="" />
              <h5>Reset Password</h5>
              <p>Create your new password to login</p>
              <h6>username@domain.com</h6>
            </div>
            {/* <div className="msg-box"></div> */}
            <div className="reset-password-controls">
                <div className="">
                    <InputBox type="password" placeholder="NewPassword" />
                </div>
                <div className="">
                    <InputBox type="password" placeholder="Confirm NewPassword" />
                </div>
                <div className="">
                    <hr />  
                </div>
                <div className="">
                    <PrimaryButton title="Set"/>
                </div>
                <a className="text-center login" href="/login"><i className="left"></i>BACK TO LOGIN</a> 
            </div>
          </div>
        </div>
        <footer>
            <p className="text-center">Copyright Predict Data. All rights reserved.<br />
                <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a>
            </p>
        </footer>
        <style jsx>{`
          .head-box {
            float:left;
            padding: 10px 50px 0 50px;
          }
          ._reset-box {
            height: 360px;
            background: #f5f5f5;
            padding: 40px;
            text-align: center;
            border-radius: 8px;
            width: 275px;
            margin-top: 91px;
          }
          ._resetBg{
            display: flex;
            height: 100%;
            flex-direction: column;
            //justify-content: center;
            align-items: center;
            background-image: url('../../static/img/bg.png');
            background-size: 100% 100%;
          }
          .logo {
            width: 100%;
            height: 118px;
            //display: flex;
            align-items: center;
            justify-content: center;
          }
          .logo img {
            width: 124px;
            height: 27px;
            margin: auto;
          }
          .logo h5 {
              font-size: 16px;
              color: #555555;
              margin: 10px 0 0 0;
          }
          .logo p {
              font-size: 12px;
              color: #a2a2a2;
          }
          .logo h6 {
              color: #616161;
              margin: 10px 0 0 0;
          }
          .reset-password-controls{
            display: flex;
            flex-direction: column;
          }
          .reset-password-controls > div {
            padding: 10px 0;
          }
          .text-center {
            text-align: center;
          }
          .text-right {
            text-align: right;
          }
          .login {
            text-decoration: none;
            font-size: 12px;
            color: #32659a;
            margin-top: 10px;
          }
          footer {
            margin-top: 20px;
          }
          footer p {
            color: #8f8f8f;
            font-size: 9px;
          }
          footer p a {
            cursor: pointer;
            text-decoration: none;
            color: #8f8f8f;
          }

          i {
            border: solid #32659a;;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 3px;
        }
        
        .left {
            transform: rotate(135deg);
        }
          
      `}</style>
      </MainLayout>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ForgotPassword)
