import React from 'react'
import withRedux from 'next-redux-wrapper'

import ManageUsers from '../components/ManageUsers'
import { initStore } from '../libs/store'


class ManageUsersAuth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  render() {
    return (
        <ManageUsers />
    )
  }
}

export default withRedux(initStore, null)(ManageUsersAuth)
