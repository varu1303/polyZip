import React, { Component } from 'react'
import axios from 'axios'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import { PrimaryButton } from '../../UI-kit/Buttons'
import MainLayout from '../../UI-kit/MainLayout'
import {InputBox} from '../../UI-kit/InputTypes'
import Title from './title'
class Login extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName: props.value,
      repoData: []
    }
  }
  getInitialProps() {

  }

  componentWillMount() {
  }

  render() {

    return (
      <MainLayout>
        <div className="head-box">
          <img src="../../static/img/predict-logo.png" alt="" />
        </div>
        <div className="container _loginBg">
          <p className="text-center">Common-sense <b>Technology Solutions</b><br/>for Enterprise Data</p>
          <div className="_login-box">
            <div className="logo">
              <img className="align-center" src="../../static/img/polymer-logo.png" className="polymer_logo" alt="" />
            </div>
            {/* <div className="msg-box"></div> */}
            <div className="login-controls">
              <div className="">
                <InputBox type="text" placeholder="Username" />
              </div>
              <div className="">
                <InputBox type="password" placeholder="******" />
              </div>
              <a className="text-right forgot-password" href="/forgotPassword">Forgot Password?</a> 
               
              <div className="">
                <hr />  
              </div>
              <div className="">
                <PrimaryButton title="Sign In"/>
              </div>
            </div>
          </div>
        </div>
        <footer>
            <p className="text-center">Copyright Predict Data. All rights reserved.<br />
                <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a>
            </p>
        </footer>
        <style jsx>{`
          .head-box {
            float:left;
            padding: 10px 50px 0 50px;
          }
          ._login-box {
            height: 360px;
            background: #f5f5f5;
            padding: 40px;
            text-align: center;
            border-radius: 8px;
            width: 275px;
          }
          ._loginBg{
            display: flex;
            height: 100%;
            flex-direction: column;
            //justify-content: center;
            align-items: center;
            background-image: url('../../static/img/bg.png');
            background-size: 100% 100%;
          }
          .logo {
            width: 100%;
            height: 158px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .logo img {
            width: 124px;
            height: 27px;
          }
          ._loginBg > p {
            font-size:24px;
            color:#fff;
            margin: 13px 0 20px 0;
          }
          //.polymer_logo{width:180px; }
          .login-controls{
            display: flex;
            flex-direction: column;
          }
          .login-controls > div {
            padding: 10px 0;
          }
          .text-center {
            text-align: center;
          }
          .text-right {
            text-align: right;
          }
          .forgot-password {
            text-decoration: none;
            font-size: 12px;
            color: #32659a;
          }
          footer {
            margin-top: 20px;
          }
          footer p {
            color: #8f8f8f;
            font-size: 9px;
          }
          footer p a {
            cursor: pointer;
            text-decoration: none;
            color: #8f8f8f;
          }
          
      `}</style>
      </MainLayout>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(Login)
