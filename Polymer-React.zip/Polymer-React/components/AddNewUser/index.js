import React, { Component } from 'react'
import axios from 'axios'
import {Router} from '../../routes'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import { PrimaryButton } from '../../UI-kit/Buttons'
import MainLayout from '../../UI-kit/MainLayout'
import {InputBox} from '../../UI-kit/InputTypes'
import Title from './title'
import Sidebar from '../../UI-kit/Sidebar'
class AddNewUser extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
      organization_Name: '',
      add1: '',
      add2: '',
      cityID: 1,
      stateID: 1,
      countryID: 1,
      zip: null,
      contactPerson: '',
      email: '',
      phone: '',
      subscriptionID: 1,
      subscription_startDate: null,
      organization_status: true
    }
  }

  postOrganization = (event) => {
    event.preventDefault();
    console.log(this.state);
    axios.post('http://localhost:1337/organization', (this.state))
      .then(data => {
        console.log(data);
        // localStorage.setItem('CreatedORGID', data.data.organizationID);
        Router.pushRoute('/addNewUser2/' + data.data.organizationID);
      })
      .catch(error => {
        console.log('Error in saving organization', error);
      })
  }

  maintainState = event => {
    let key = event.target.id;
    let val = event.target.value;
    if (key === 'cityID' || key === 'stateID' || key === 'countryID' || key === 'phone' || key === 'subscriptionID')
      val = parseInt(val);
    // if (key === 'zip') 
    //   val = null;
    this.setState(() => {
      return ({
        [key]: val
      })
    })
  }

  getInitialProps() {

  }

  componentWillMount() {
  }

  render() {

    return (
    <div>
            <Sidebar />
            <div className="mainpage">
            <div>
                <div className="headerpart">
                    <h2>ADD NEW CUSTOMERS</h2>
                    <p>Logged in as Administrator-<span className="font-weight-bold">Clinton, S </span><i className="down"></i></p>
                </div>
                <div className="wizard">
                    <a className="current" href="#"><span className="badge">1</span>Customer Details</a>
                    <a><span className="badge" href="#">2</span>Add Users</a>
                    <a><span className="badge" href="#"> </span></a>
                </div>
            </div>
            <div className="bodypart">
                <form action="#" onSubmit={this.postOrganization} onChange={this.maintainState} >
                    <fieldset>
                        <legend>General Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="customer-name">Customer Name</label>
                            <input className="maininputs" name="customer-name" type="text" id="organization_Name" value={this.state.organization_name} />
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Address Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="address-line-1">Address Line 1</label>
                            <input className="maininputs" name="address-line-1" type="text" id="add1" value={this.state.add1} />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="address-line-2">Address Line 2</label>
                            <input className="maininputs" name="address-line-2" type="text" id="add2" value={this.add2} />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="country">Country</label>
                            <select className="countrydropdown" name="country"  id="countryID" value={this.state.countryID}>
                                <option value="1">India</option>
                                <option value="2">IN</option>
                            </select>
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="state">State</label>
                            <select className="statedropdown" name="state"  id="stateID" value={this.state.stateID}>
                              <option value="1">Maha</option> 
                              <option value="2">Maharashtra</option>
                            </select>
                            <label className="citylabel" htmlFor="city">City</label>
                            <select className="citydropdown" name="city"  id="cityID" value={this.state.cityID}>
                                <option value="1">Pune</option>
                                <option value="2">Pun</option>
                            </select>
                            <label className="secondarylabels" htmlFor="postal-code">Postal Code</label>
                            <input className="postalcodeinput" name="postal-code" type="text" />
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Contact Info</legend>
                        <p>
                            <label className="mainlabels" htmlFor="contact-person">Contact Person</label>
                            <input className="contactinfoinput" name="contact-person" type="text"  id="contactPerson" value={this.state.contactPerson} />
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="email-id">E-mail ID</label>
                            <input className="contactinfoinput" name="email-id" type="email" id="email" value={this.state.email} />
                            <label className="secondarylabels" htmlFor="phone">Phone</label>
                            <input className="contactinfophoneinput" name="phone" type="text"  id="phone" value={this.state.phone}/>
                        </p>
                    </fieldset>
                    <fieldset>
                        <legend>Subscription Details</legend>
                        <p>
                            <label className="mainlabels" htmlFor="subscription">Select Subscription</label>
                            <select className="subscriptiondropdown" name="subscription"  id="subscriptionID" value={this.state.subscriptionID}>
                                <option value="1">Platinum</option>
                                <option value="2">Gold</option>
                            </select>
                        </p>
                        <p>
                            <label className="mainlabels" htmlFor="duration">Duration</label>
                            <select className="durationdropdown" name="duration">
                                <option value="1">1 Year</option>
                            </select>
                            <label className="secondarylabels" htmlFor="starts-from">Starts from</label>
                            <input name="starts-from" type="date"  id="subscription_startDate" value={this.state.subscription_startDate} />
                        </p>
                    </fieldset>
                    <div className="buttons">
                        <p>
                            <button className="primarybutton" type="submit">Save & Next</button>
                            <button className="secondarybutton" type="reset">Reset</button>
                        </p>
                        <p>
                            <button className="secondarybutton">Cancel</button>
                        </p>
                    </div>
                </form>
            </div>
        </div>
        <style jsx>{`
          .mainpage {
                height: 100%;
                margin-left: 15%;
                width: 85%;
            }

            /* Top header */
            .headerpart {
                display: flex;
                width: 98%;
                padding: 10px;
                background-color: #ffffff;
                border-bottom-style: solid;
                border-width: 1px;
                border-bottom-color: lightgrey;
                justify-content: space-between;
            }

            /* Heading */
            .headerpart h2 {
                font-size: 14px;
                margin: 0;
            }

            /* Logged in as */
            .headerpart p {
                font-size: 12px;
                margin: 0;
            }
            .headerpart p i {
                border: solid black;
                border-width: 0 3px 3px 0;
                display: inline-block;
                padding: 3px;
            }
            .headerpart p .down {
                transform: rotate(45deg);
                -webkit-transform: rotate(45deg);
            }

            .wizard {
                margin: 20px;
            }

            .wizard a {
                padding: 10px 12px 10px;
                margin-right: 5px;
                background: #bbcede;
                position: relative;
                display: inline-block;
                width: 171px;
                cursor: pointer;
                font-size: 16px;
                text-decoration: none;
            }
            .wizard a:last-child {
                width: calc(100% - 366px);
                backbackground: #d0dbe5;
            }
            .wizard a:before {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid rgb(236, 236, 236);
                position: absolute;
                content: "";
                top: 0;
                left: 0;
            }
            .wizard a:after {
                width: 0;
                height: 0;
                border-top: 20px inset transparent;
                border-bottom: 20px inset transparent;
                border-left: 20px solid rgb(187, 206, 221);
                position: absolute;
                content: "";
                top: 0;
                right: -20px;
                z-index: 2;
            }
            .wizard a:first-child:before,
            .wizard a:last-child:after {
                border: none;
            }

            .wizard a:first-child {
                -webkit-border-radius: 4px 0 0 4px;
                -moz-border-radius: 4px 0 0 4px;
                        border-radius: 4px 0 0 4px;
            }
            .wizard a:last-child {
                -webkit-border-radius: 0 4px 4px 0;
                -moz-border-radius: 0 4px 4px 0;
                        border-radius: 0 4px 4px 0;
            }
            .wizard .badge {
                margin: 0 5px 0 18px;
                position: relative;
                top: -1px;
                color: #003366;
                background-color: white;
            }
            .wizard a:first-child .badge {
                margin-left: 0;
            }
            .wizard .current {
                background: #dd4852;
                color: #fff;
            }
            .wizard .current:after {
                border-left-color: #dd4852;
            }

            .bodypart {
                margin: 20px;
            }

            legend {
                font-size: 13px;
                line-height: 20px;
                margin-bottom: 0;
                width: auto;
                /* padding: 0 10px; */
                font-weight: bold;   
            }

            fieldset {
                border: 1px solid #d0dbe5;
                padding: 10px;
            }

            .buttons {
                display: flex;
                margin-top: 20px;
                justify-content: space-between;
            }

            .bodypart p {
                margin-bottom: 10px;
            }

            .mainlabels {
                width: 140px;
                margin-right: 10px;
                font-size: 13px;
                display: inline-block;
            }

            .secondarylabels {
                width: 85px;
                margin-right: 10px;
                margin-left: 50px;
                font-size: 13px;
                display: inline-block;
            }

            .citylabel {
                margin-right: 10px;
                margin-left: 50px;
                width: 50px;
                font-size: 13px;
                display: inline-block;
            }

            .maininputs {
                width: 390px;
                font-size: 14px;
            }

            .countrydropdown {
                width: 200px;
                font-size: 14px;
            }

            .statedropdown {
                width: 120px;
                font-size: 14px;
            }

            .citydropdown {
                width: 150px;
                font-size: 14px;
            }

            .contactinfoinput {
                width: 300px;
                font-size: 14px;
            }

            .contactinfophoneinput {
                width: 180px;
                font-size: 14px;
            }

            .postalcodeinput {
                width: 130px;
                font-size: 14px;
            }

            .subscriptiondropdown {
                width: 150px;
                font-size: 14px;
            }

            .durationdropdown {
                width: 110px;
                font-size: 14px;
            }

            .primarybutton {
                margin: 0 10px 0 0;
                padding: 0;
                height: 40px;
                cursor: pointer;
                width: 120px;
                color: white;
                background-color: rgb(50, 101, 153);
                font-size: 14px;
            }

            .secondarybutton {
                margin: 0 10px 0 0;
                padding: 0;
                height: 40px;
                cursor: pointer;
                width: 120px;
                color: rgb(50, 101, 153);
                background-color: white;
                border: 1px solid rgb(50, 101, 153);
                font-size: 14px;
            }
      `}</style>
    </div>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(AddNewUser)
