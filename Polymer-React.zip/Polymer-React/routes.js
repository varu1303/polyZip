const routes = module.exports = require('next-routes')()
 
// routes
// .add('login')
// .add('organization', '/manageCustomers')
// .add('user', '/manageUsers')
// .add('addOrg', '/addNewUser')
// .add('addUser', '/addNewUser2')