import React from 'react'
import withRedux from 'next-redux-wrapper'

import ForgotPassword from '../components/ForgotPassword'
import { initStore } from '../libs/store'


class ForgotPasswordAuth extends React.Component{
    constructor(props, context) {
      super(props, context)
      this.state = {
        repoName :props.value
      }
    }
  
    render() {
      return (
          <ForgotPassword />
      )
    }
  }
  
  export default withRedux(initStore, null)(ForgotPasswordAuth)
  