import React, { Component } from 'react'
import axios from 'axios'
import {connect} from 'react-redux'
import { bindActionCreators } from 'redux'
import {fetchGitHubRepos, fetchGitHubUser} from './repoListActionCreator'
import { PrimaryButton } from '../../UI-kit/Buttons'
import MainLayout from '../../UI-kit/MainLayout'
import {InputBox} from '../../UI-kit/InputTypes'
import Title from './title'
class ForgotPassword extends Component{


  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName: props.value,
      repoData: []
    }
  }
  getInitialProps() {

  }

  componentWillMount() {
  }

  render() {

    return (
      <MainLayout>
        <div className="head-box">
          <img src="../../static/img/predict-logo.png" alt="" />
        </div>
        <div className="container _forgotBg">
          {/* <p className="text-center">Common-sense <b>Technology Solutions</b><br/>for Enterprise Data</p> */}
          <div className="_forgot-box">
            <div className="logo">
              <img className="align-center" src="../../static/img/polymer-logo.png" alt="" />
              <h6>Forgot Password</h6>
              <p>Don't worry! Just fill in your <br />email and we'll help you reset <br />your password.</p>
            </div>
            {/* <div className="msg-box"></div> */}
            <div className="forgot-password-controls">
              
              <div className="">
                <InputBox type="email" placeholder="Email" />
              </div>
              
               
              <div className="">
                <hr />  
              </div>
              <div className="">
                <PrimaryButton title="Send Email"/>
              </div>
              
              
                  <a className="text-center login" href="/login"><i className="left"></i>BACK TO LOGIN</a> 
              
            </div>
          </div>
        </div>
        <footer>
            <p className="text-center">Copyright Predict Data. All rights reserved.<br />
                <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a>
            </p>
        </footer>
        <style jsx>{`
          .head-box {
            float:left;
            padding: 10px 50px 0 50px;
          }
          ._forgot-box {
            height: 360px;
            background: #f5f5f5;
            padding: 40px;
            text-align: center;
            border-radius: 8px;
            width: 275px;
            margin-top: 91px;
          }
          ._forgotBg{
            display: flex;
            height: 100%;
            flex-direction: column;
            //justify-content: center;
            align-items: center;
            background-image: url('../../static/img/bg.png');
            background-size: 100% 100%;
          }
          .logo {
            width: 100%;
            height: 158px;
            //display: flex;
            align-items: center;
            justify-content: center;
          }
          .logo img {
            width: 124px;
            height: 27px;
            margin: auto;
          }
          .logo h6 {
              font-size: 16px;
              color: #555555;
              margin: 20px 0;
          }
          .logo p {
              font-size: 12px;
              color: #a2a2a2;
          }
          .forgot-password-controls{
            display: flex;
            flex-direction: column;
          }
          .forgot-password-controls > div {
            padding: 10px 0;
          }
          .text-center {
            text-align: center;
          }
          .text-right {
            text-align: right;
          }
          .login {
            text-decoration: none;
            font-size: 12px;
            color: #32659a;
            margin-top: 30px;
          }
          footer {
            margin-top: 20px;
          }
          footer p {
            color: #8f8f8f;
            font-size: 9px;
          }
          footer p a {
            cursor: pointer;
            text-decoration: none;
            color: #8f8f8f;
          }

          i {
            border: solid #32659a;;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 3px;
        }
        
        .left {
            transform: rotate(135deg);
        }
          
      `}</style>
      </MainLayout>
    )
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchGitHubRepos: bindActionCreators(fetchGitHubRepos, dispatch),
    fetchGitHubUser: bindActionCreators(fetchGitHubUser, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    repoData: state.fetchRepo.repoData,
    userData: state.UserInfo.userInfo
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(ForgotPassword)
