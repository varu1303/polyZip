import React from 'react'
import styled from 'styled-components'

const InputText = styled.input.attrs({
  type: props => props.type || 'text',
  placeholder: props => props.placeholder || ''

})`
  color: #a8a8a8;
  font-size: 12px;
  background: #fff;
  // border-radius: 5px;
  padding: 10px;
  // webkit-box-shadow: 0px 3px 5px -1px rgba(120,115,120,1);
  // -moz-box-shadow: 0px 3px 5px -1px rgba(120,115,120,1);
  // box-shadow: 0px 3px 5px -1px rgba(120,115,120,1);
  width: 250px;
  // height: 50px;
`
export default (props) => {
  console.log(props)
  return <InputText type={props.type} placeholder={props.placeholder}/>
    // <InputText type={props.placeholder}/>
}
