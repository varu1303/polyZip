import React from 'react'
import styled from 'styled-components'

const MainLayout = styled.div`
  width:100%;
  display:flex;
  background: #d7d7d7;
  flex-direction: column;
  height: 100%;
`
export default (props) => {
  console.log(props)
  return <MainLayout>{props.children}</MainLayout>
}
