import React from 'react'
import withRedux from 'next-redux-wrapper'

import ManageCustomers from '../components/ManageCustomers'
import { initStore } from '../libs/store'


class ManageCustomersAuth extends React.Component{
  constructor(props, context) {
    super(props, context)
    this.state = {
      repoName :props.value
    }
  }

  render() {
    return (
        <ManageCustomers />
    )
  }
}

export default withRedux(initStore, null)(ManageCustomersAuth)
