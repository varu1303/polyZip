import React from 'react'
import styled from 'styled-components'

const PrimaryButton = styled.button`
  color: #fff;
  font-size: 16px;
  border: 1px solid #fff;
  background: #32659a;
  border-radius: 5px;
  padding: 10px;
  width: 100%;
  height: 50px;
  cursor: pointer;
`
export default (props) => {
  console.log(props)
  return <PrimaryButton>{props.title}</PrimaryButton>
}
