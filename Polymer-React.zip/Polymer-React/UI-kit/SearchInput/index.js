import React, {Component} from 'react'
import Auxiliary from '../../components/HOC/Auxiliary'
import Autosuggest from 'react-autosuggest';

class SearchInput extends Component {
    search = (event) => {
        event.preventDefault();
        
    }
    render () {
        return(
            <Auxiliary>
                <form className="search_form" action="#" onSubmit={this.search} >
                        <button className="search_icon" type="submit"></button>

                        <input type="search" autoComplete="On" />
                        <button className="close_icon" onClick = { this.props.closeButton }>X</button>
                        <style jsx>{`
                        .search_form {
                            width: 100%;
                        }
                        form.search_form input[type=search] {
                            font-size: 14px;
                            border: 1px solid grey;
                            float: center;
                            width: 90%;
                            height: 40px;
                            border-left: none;
                            border-right: none;
                        }
                        form.search_form button {
                            font-size: 14px;
                            cursor: pointer;
                            height: 40px;
                            padding: 0;
                            width: 5%;
                            background-color: white;
                        }
                        .search_icon {
                            float: left;
                            background-image: url('../../static/img/search.png');
                            background-repeat: no-repeat;
                            background-position: center;
                            border: 1px solid grey;
                            border-right: none;
                        }
                        .close_icon {
                            float: right;
                            border: 1px solid grey;
                            border-left: none;
                        }
                        form.search_form::after {
                            content: "";
                            clear: both;
                            display: table;
                        }
                        `}</style>
                </form>
            </Auxiliary>

        )
    }
}

export default SearchInput;