import React, { Component } from 'react'
import {Link} from '../../routes'
import axios from 'axios'
import styled from 'styled-components'
import Auxiliary from '../../components/HOC/Auxiliary'

const Sidebar = (props) => (
            <Auxiliary>
                <div className="sidebar">
                    <h1 className="text-center"><img src="../../static/img/polymer-logo.png" alt="" /></h1>
                    <nav>
                        <ul>
                            <li><a href="#">DASHBOARD</a></li>
                            <li><Link route='/manageCustomers'><a href="/manageCustomers">CUSTOMERS</a></Link></li>
                            <li><Link route='/manageUsers'><a href="/manageUsers">USER MANAGEMENT</a></Link></li>
                            <li><Link route='/blog/hello-world'><a href="#">REPORTS</a></Link></li>
                        </ul>
                    </nav>
                    <hr />
                </div>
                <style jsx>{`
                    .sidebar {
                        height: 100%;
                        width: 15%;
                        background-color: #326599;
                        //font-weight: bold;
                        color: #fff;
                        padding: 10px 0;
                        position: fixed;
                        z-index: 1;
                        top: 0;
                        left: 0;
                        overflow-x: hidden;
                    }
                    .sidebar h1 {
                        margin: 0;
                    }
                    .sidebar h1 img {
                        width: 100px;
                        height: 25px;
                        margin: auto;
                    }
                    .sidebar ul {
                        list-style: none;
                        margin: 0;
                        padding: 0;
                    }
                    .sidebar ul li {
                        text-align: left;
                    }
                    .sidebar ul li a {
                        color: inherit;
                        text-decoration: none;
                        cursor: pointer;
                        font-size: 14px;
                        padding: 8px 16px 8px 16px;
                        display: block;
                    }
                    .sidebar ul li a:active,
                    .sidebar ul li a:hover {
                        font-weight: bold;
                        background-color: #7094b8;
                    }
                    .text-center {
                        text-align: center;
                    }
                `}</style>
            </Auxiliary>
        );


export default Sidebar;