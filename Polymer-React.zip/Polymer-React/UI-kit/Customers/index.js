import React, { Component } from 'react'
import axios from 'axios'
import Auxiliary from '../../components/HOC/Auxiliary'
import {Link} from '../../routes'
import {Router} from '../../routes'

const Customers = (props) => (
            <Auxiliary>
                <div className="subscribers">
                    <div className="buildingicon text-center">
                        <p className="normal">
                            <img src="../../static/img/default.png" />
                        </p>
                        <p className="hoverable">
                            {/* <Router pushRoute={'/addNewUser2/' + props.id }><button className="edit"></button></Router> */}
                            <Link route= {'/editOrganization/' + props.orgID }><button className="edit"></button></Link>
                            {/* <Link route= {'/editOrganization/' }><button className="edit"></button></Link> */}
                            <button className="delete"></button>
                        </p>
                    </div>
                    <div className="address">
                        <Link route={'/manageUsers/'+props.orgID} ><h4>{props.name}</h4></Link>
                        <p>{props.address}</p>
                        <p>{props.users}</p>
                        <hr />
                    </div>
                    <div className="subscriptiontype">
                        <p className="gold"><span>Gold</span></p>
                        <p>Subscription Valid from <br />{props.date}</p>
                    </div>
                </div>
                <style jsx>{`
                    .subscribers {
                        border-radius: 5px;
                        
                        width: 202px;
                        background-color: white;
                        margin: 23px 0px 0px 23px;
                        display: inline-block;
                        height: 260px;
                    }
                    
                    .subscribers .buildingicon {
                        height: 86px;
                        background: #f8f8f8;
                        text-align: center;
                        border-radius: 5px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }

                    .subscribers .buildingicon img {
                        height: 73px;
                        width: 76px;
                        margin: auto;
                    }
                    
                    .subscribers .buildingicon .hoverable {
                        display: none;
                    }
                    
                    .subscribers .buildingicon:hover {
                        background: #326599;
                    }
                    .normal {
                        margin: 0;
                    }
                    .hoverable {
                        margin: 0;
                    }
                    .subscribers .buildingicon:hover button {
                        background-color: #5b84ad;
                        border: none;
                        margin: auto 5px;
                        border-radius: 5px;
                        height: 41px;
                        width: 41px;
                        cursor: pointer;
                    }
                    
                    .subscribers .buildingicon:hover .normal {
                        display: none;
                    }
                    
                    .subscribers .buildingicon:hover .hoverable {
                        display: inline;
                    }

                    .subscribers .address {
                        padding: 5px;
                    }
                    
                    .subscribers .address h4 {
                        font-size: 12px;
                        color: #326599;
                        margin: 0;
                        cursor: pointer;
                    }
                    
                    .subscribers .address hr {
                        margin: 10px 0;
                    }
                    
                    .subscribers .address p {
                        margin: 0 0 10px 0;
                        font-size: 11px;
                    }

                    .subscribers .subscriptiontype {
                        padding: 5px;
                    }
                    
                    .subscribers .subscriptiontype p{
                        font-size: 12px;
                    }
                    
                    .gold {
                        background-color: #d7a407;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }
                    
                    .premiun {
                        background-color: #dd4852;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }
                    
                    .basic {
                        background-color: #2a2a2a;
                        width: 50px;
                        color: white;
                        text-align: center;
                    }

                    .edit {
                        background-image: url('../../static/img/edit.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }

                    .delete {
                        background-image: url('../../static/img/delet.png');
                        background-repeat: no-repeat;
                        background-position: center;
                        height: 52px;
                        width: 52px;
                    }
                `}</style>
        </Auxiliary>
);

export default Customers;